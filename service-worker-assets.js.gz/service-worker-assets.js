self.assetsManifest = {
  "version": "QoAKlXOT",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-0UJD+gRLMSW2QDE1+siPH+TH4z9X7VlhdRhsqbOcsZU=",
      "url": "_framework/Services.Base64.jbhaz5lfpt.wasm"
    },
    {
      "hash": "sha256-4EQppNynZ+ShSsY17FwKwHL6PUnLIm559avI3iaKEzY=",
      "url": "_framework/Services.Hashing.kj6kl2yjmh.wasm"
    },
    {
      "hash": "sha256-GdM6ErPqXSOYdJ1D3i/w9I+gjh2g/pK2pbRfguy/Thc=",
      "url": "_framework/Services.Url.7wuikvlkwh.wasm"
    },
    {
      "hash": "sha256-yqC1g5CWPccH0c6TgI3O49v+esypK9NdObYUh8tPtxE=",
      "url": "_framework/System.Collections.2uldl7kwyg.wasm"
    },
    {
      "hash": "sha256-rYyTL7cXT/j2DIGZ740qga75W7kGtouBsIrxOzrKaAM=",
      "url": "_framework/System.Collections.Concurrent.nf2gjk4443.wasm"
    },
    {
      "hash": "sha256-0ch7crxnDd1ZGbzxTSdfUjStSxC3wq8DaQxGxWU7vWk=",
      "url": "_framework/System.Collections.Immutable.9yo693z5ya.wasm"
    },
    {
      "hash": "sha256-5UHPK3Zww3wuyf6emXP1IBdseu2zZSxNQRwr22SWuVw=",
      "url": "_framework/System.ComponentModel.Annotations.t63vc5ilyt.wasm"
    },
    {
      "hash": "sha256-juPoBz9cO0qEbybweWe8Z3ZP4kHQfhnu4xKKB/Kavfg=",
      "url": "_framework/System.ComponentModel.Primitives.e5rcsr2wfb.wasm"
    },
    {
      "hash": "sha256-4E91P11gDLPaQN5QlJbpJYzcW3vrY8O0yyRzRVRd6D4=",
      "url": "_framework/System.ComponentModel.TypeConverter.o2g3kub7v0.wasm"
    },
    {
      "hash": "sha256-JWhXQOPEahjRZFVHQx9ZpvbCcgrab4e+rm6ltdkzQU8=",
      "url": "_framework/System.ComponentModel.ffr4se6p83.wasm"
    },
    {
      "hash": "sha256-cMcVyFleU5JBjefYzFA+ZCqiKVCe2D3MP5f7yAVfbjw=",
      "url": "_framework/System.Console.gg2ckbhm27.wasm"
    },
    {
      "hash": "sha256-3Lz/C3xvZYot8WZ1sdBsAmoiVX4ZhaD3Cvy2WIezAO0=",
      "url": "_framework/System.Diagnostics.Debug.wncz6ffdi4.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-Ab9x/bJqcQL+B/ZXNwIm1EQKXB7d6TVG+4qUuJiGIao=",
      "url": "_framework/System.IO.Pipelines.nawu2omdpm.wasm"
    },
    {
      "hash": "sha256-Zk/PxddMURWmVCmeToj5Y/mjKXO6Fz3o8NZSNTBRvd4=",
      "url": "_framework/System.Linq.6dsse10zkx.wasm"
    },
    {
      "hash": "sha256-EbSNuoPwD4FLRdJtGouUtdN9JUfNJEiI51fW2a96+DU=",
      "url": "_framework/System.Linq.Expressions.ddrequ6duu.wasm"
    },
    {
      "hash": "sha256-oiQXK0CNoDmkEPfToJMChv9+fyGqMrO9HpFvUghFG88=",
      "url": "_framework/System.Memory.6i5iz3wgp3.wasm"
    },
    {
      "hash": "sha256-ksybm/xq9Ov9xkwduiK2nmOnTnIFDKZSBCy9Hy/jThg=",
      "url": "_framework/System.Net.Http.62i4vg0dbu.wasm"
    },
    {
      "hash": "sha256-2R6oA00wWXWat/EHPEbKEewXBRGQ92Hb1XTzrgJjuxA=",
      "url": "_framework/System.Net.Primitives.vicfg18vaz.wasm"
    },
    {
      "hash": "sha256-uJZJsfG3GNJZAgXeXeojYFKHPEdcB7/Jcu6LJ8BsoWc=",
      "url": "_framework/System.ObjectModel.kljyv04tpd.wasm"
    },
    {
      "hash": "sha256-zEk+oW6RII3DbLh+ysIcEHj+AfX69CrLCmrVutNB8Kg=",
      "url": "_framework/System.Private.CoreLib.ce3gxst3vc.wasm"
    },
    {
      "hash": "sha256-KuYOfO72/BX/4Y8W1Q4S1iAhUhdxTPBdjG9ROnQp0Rs=",
      "url": "_framework/System.Private.Uri.yh1xci0m91.wasm"
    },
    {
      "hash": "sha256-73kVpPqW91LMVnwRrIPCVTyfpWt7KfjD9ebSBoTRVZQ=",
      "url": "_framework/System.Resources.ResourceManager.hkv10cczm3.wasm"
    },
    {
      "hash": "sha256-L03m+023IPzRHxTy4UTblXxzEyeTMBdiYZehNoVCKm4=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.tl8hppn9o8.wasm"
    },
    {
      "hash": "sha256-Nr/IlRKxTb2lHO3ucioef100QsU4O7bGnIfS8j2yPQ4=",
      "url": "_framework/System.Runtime.erny01z3ak.wasm"
    },
    {
      "hash": "sha256-zD4Qke4oOl0FYEuZ4rDQhVLqBy653mWAMSMadUftRPo=",
      "url": "_framework/System.Security.Cryptography.c8qsnlyjkb.wasm"
    },
    {
      "hash": "sha256-pkXHi3UZiEv9k24SwY7SToec+qk8wepwE9DH9N9e2eQ=",
      "url": "_framework/System.Text.Encodings.Web.acev43jfsj.wasm"
    },
    {
      "hash": "sha256-fSEINs7xhrnUXBXuu11l14Soii2WL7r75UJM9sQZZ+s=",
      "url": "_framework/System.Text.Json.382pn0lhao.wasm"
    },
    {
      "hash": "sha256-aj6DgF7AOsMmjRFL2/fiJMtvYVgEuNMjmHXYS5cS3HM=",
      "url": "_framework/System.Text.RegularExpressions.2mpfn29nyh.wasm"
    },
    {
      "hash": "sha256-/NQfQpBpXAmloYSch6meJEHCykDIhwHLu0v5FnN5Q0Y=",
      "url": "_framework/System.Threading.Tasks.kccauolpwy.wasm"
    },
    {
      "hash": "sha256-+RGeMNzJKSWnf53s3f9WD9VoxGZWUh51oZnEQzh2PLk=",
      "url": "_framework/System.fuo59yvmx8.wasm"
    },
    {
      "hash": "sha256-QQJwJ5NgDfjJQE2GRnpJKB7YSMRZCQE6Awqr1AwUa2s=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-CA9FMOebtZ9qjFLtD2DNPg1K3SOLZqJt9c2i9en7TFM=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-cyurmk3Ak+seyp/QVHpPtXEhK3hn1GmYBbg7VYc4tWk=",
      "url": "_framework/dotnet.native.fd55pqaqpk.js"
    },
    {
      "hash": "sha256-H6quBtWTahdhixnr/D36sa9se3RJyJ3VlujeSMPePqE=",
      "url": "_framework/dotnet.native.vww2n0y4ua.wasm"
    },
    {
      "hash": "sha256-4kOU7tA6RzZadM/Bp0bGS4APXC7Z7XfrXpcFWsH0znc=",
      "url": "_framework/dotnet.runtime.qa25pgzyet.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ZQ+nqJit1JWjZU7tOVRDBoaqgkpEM99/3rarwVgTWSw=",
      "url": "_framework/theonlytool.r0k115cdja.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
