self.assetsManifest = {
  "version": "Y2qYHcF/",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-V0g9bHzPENbMC2O9tONGcTKQz0IXEPu85nRF+pzTSkw=",
      "url": "_framework/Services.Base64.lx3r7h287c.wasm"
    },
    {
      "hash": "sha256-4uw80ta4YHf6N8UKE8284pbVeBS/M2SmjDWz61TerdE=",
      "url": "_framework/Services.Hashing.qtnyeuytnk.wasm"
    },
    {
      "hash": "sha256-CG5OUKSnA7+MDWiFUgpiHInwGt+2avShbKBe2hB8Dcw=",
      "url": "_framework/Services.Url.8c0db1o96l.wasm"
    },
    {
      "hash": "sha256-Jr+Spe/SKEnyQ6k0OLVNxpXxspWpzskzjh9heOu2cfo=",
      "url": "_framework/System.Collections.Concurrent.mhu2a07e6l.wasm"
    },
    {
      "hash": "sha256-EvZdLDsacM9edQI7J3iwR2fy9jaLQUuTWVO+XIZ/hzY=",
      "url": "_framework/System.Collections.Immutable.e98h6njsix.wasm"
    },
    {
      "hash": "sha256-mZzKQUMBX7CnZRX9cnDv1A/rQ9+CRXzIR4U3Wkxcqb0=",
      "url": "_framework/System.Collections.bnqu9a7cun.wasm"
    },
    {
      "hash": "sha256-jUAcQCQV/ZRoT8grSZoXaXFuEo/YZLtfWRY5x1Xr170=",
      "url": "_framework/System.ComponentModel.1f3lg3ghkv.wasm"
    },
    {
      "hash": "sha256-qt0kNn5+Mr5ApYUM7t20XebbYQ6vgh0gRNlVOx2lFnc=",
      "url": "_framework/System.ComponentModel.Annotations.qcq59s34ag.wasm"
    },
    {
      "hash": "sha256-iEhAufN2NhZcS28uZOXHrPBF51+1E31t/fuOBPiYqUE=",
      "url": "_framework/System.ComponentModel.Primitives.wiq5v976rm.wasm"
    },
    {
      "hash": "sha256-OD7SZgi/sgJZhdsfGFTB6yhOq1K+hDbRN4AG3sWDwq4=",
      "url": "_framework/System.ComponentModel.TypeConverter.454leqkiyu.wasm"
    },
    {
      "hash": "sha256-aUVTvgmUQ8N19O+6xyVn9SoyzPBfAxFWpp9GUQd7V5M=",
      "url": "_framework/System.Console.tjq0zvynoy.wasm"
    },
    {
      "hash": "sha256-0IHRC4HNshU0yY/oRBLFnixfQZVfO6F3wRUxA0+lKhs=",
      "url": "_framework/System.Diagnostics.Debug.woh5hiihpw.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-7fR3N9MEeChVFQwhQ2El+gkedxmDBEoFxEDHTBc8egg=",
      "url": "_framework/System.IO.Pipelines.52aogfoqdp.wasm"
    },
    {
      "hash": "sha256-VyTvy5duCH0ZIa49Cmk1YrySp4oB9uSd09iCIz27xSY=",
      "url": "_framework/System.Linq.Expressions.f2om180pky.wasm"
    },
    {
      "hash": "sha256-pbo8zzq8J86p9ihf1Rw5Tz//hUPSzt8Ym29aQmxIRV0=",
      "url": "_framework/System.Linq.jyogft68qv.wasm"
    },
    {
      "hash": "sha256-8WY5f2bEylVfXuvwFA3LYHq2p/wXssc6CJW6b2asfik=",
      "url": "_framework/System.Memory.d1kihou1vu.wasm"
    },
    {
      "hash": "sha256-2VNJFcHVvEOxfXa62qdh4UKKyuZpPmju/vUOh6KquDY=",
      "url": "_framework/System.Net.Http.bjfeqndavr.wasm"
    },
    {
      "hash": "sha256-yObRoP8wp6GQaRCqaUU6HCPt7pXNNCoK6Kc3EyQTRI4=",
      "url": "_framework/System.Net.Primitives.wav3848x1p.wasm"
    },
    {
      "hash": "sha256-8s2nZAcm+KuZY3QxuCs3tGx9DXHLTEtWnZm+ZGKXiKA=",
      "url": "_framework/System.ObjectModel.q1xzkzaccv.wasm"
    },
    {
      "hash": "sha256-JAE2kWR0j85KpWSib/TTLStoHA6+QhYCxRe8wbWGhPg=",
      "url": "_framework/System.Private.CoreLib.kks2gdi2cu.wasm"
    },
    {
      "hash": "sha256-KfOOwwVgzOCyiGTq3weqX1ZNhHNRLd4nj7eo0FzDqyE=",
      "url": "_framework/System.Private.Uri.zterxyoy0y.wasm"
    },
    {
      "hash": "sha256-4jr5G3IunGourSVVpS6IkilAp1HDQ820eyeFUFbdM0o=",
      "url": "_framework/System.Resources.ResourceManager.20qxd7xi02.wasm"
    },
    {
      "hash": "sha256-D7zUMmvQGq6/86QXq4/FMXLHt+dmvf3HI1iXe8Gr3Fo=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ljbeaupw5z.wasm"
    },
    {
      "hash": "sha256-LqWYDuWDat2dDEdtCf9mZ21DFCmgJgbAF6ee6kTu/Sg=",
      "url": "_framework/System.Runtime.aiwd1l2dds.wasm"
    },
    {
      "hash": "sha256-cY4Fh4YFsFqbnNBH48Ms76edWTY4RXRgKUA35une9Do=",
      "url": "_framework/System.Security.Cryptography.rprhb0qtb1.wasm"
    },
    {
      "hash": "sha256-/1ZwMLgugRWSt+5QMn6mIPROgt1U1lVUCA8gdF7q2QQ=",
      "url": "_framework/System.Text.Encodings.Web.lj09apf4g1.wasm"
    },
    {
      "hash": "sha256-qRqNjjS1W2C5c0blzUJNg/cVkWLDhXu0qjiy+ZhVvjk=",
      "url": "_framework/System.Text.Json.78309vhl3l.wasm"
    },
    {
      "hash": "sha256-sqLiHEuhaTOOi+1Mq/wjFrsumBJKGZIGwscr6t7JHL0=",
      "url": "_framework/System.Text.RegularExpressions.a5xuye8ml5.wasm"
    },
    {
      "hash": "sha256-TETJ/gFnbaI9ZRdsB/8wQMUXirw7Kz3c10lBTe68KyU=",
      "url": "_framework/System.Threading.Tasks.c479c30l8z.wasm"
    },
    {
      "hash": "sha256-cIBJAKdiktlvxbM24Ex0iujEEkSp1KIeoyzJ27gJ4YY=",
      "url": "_framework/System.w40v23gp3a.wasm"
    },
    {
      "hash": "sha256-7xlxF5+0tVD+Ox7F18ZK9zZFIjmvO+s/7plC0v5g6bs=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-AOco/F90L7lg4nfQqaMH4OLi3RY8p6tFVZVz6N4lBRE=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-xHeqoXqAr4yxPSIa3v8IkB69qUpPtGwi/SGESnrAqyM=",
      "url": "_framework/dotnet.native.kiufslnrq2.wasm"
    },
    {
      "hash": "sha256-/FFh+hncmkDjkVdq8mZIy51/nXHJPYNgd/njEJAau7U=",
      "url": "_framework/dotnet.native.wlvwu26j41.js"
    },
    {
      "hash": "sha256-/zZ5MThbtViNFadyOTkZ+QQ4labN7SSGWO57glfyLYk=",
      "url": "_framework/dotnet.runtime.x4l8oxbjyh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-VqIhWk4GetvIAC70y7VIL1hF2m9bcTlWpWk1rHmAa+E=",
      "url": "_framework/theonlytool.a022fiz769.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
