self.assetsManifest = {
  "version": "OT3yrewY",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-rFrTGT+v66tnzF8Y/R68qlZiWkKCaOqUR7JQFQf62XU=",
      "url": "_framework/Services.Base64.c41gd9w40g.wasm"
    },
    {
      "hash": "sha256-2jWbF/svjNKIdYVgujhByDmqRDHXuW3J5V0Ldmdz1B0=",
      "url": "_framework/Services.Hashing.mojmdsmh86.wasm"
    },
    {
      "hash": "sha256-vXzlbYqy1K+hgYfcfAGiHBu69J2EB/yGfal4IK06+i4=",
      "url": "_framework/Services.Url.v14rei23cn.wasm"
    },
    {
      "hash": "sha256-eH2kpcY51ajriZClDOuW81DxRdqG3CIThNnAkhDxAVc=",
      "url": "_framework/System.Collections.80wmfe17bq.wasm"
    },
    {
      "hash": "sha256-m53Pc5d0riJJwoJ+Hpwnnht7XVV/zPg9KXusZFlNbTo=",
      "url": "_framework/System.Collections.Concurrent.3yt4pl82vy.wasm"
    },
    {
      "hash": "sha256-AKGvT+8X68bgYnvXggIQxRBIbaFLdhBzsLIUMoGpPxE=",
      "url": "_framework/System.Collections.Immutable.knnx5dz3s2.wasm"
    },
    {
      "hash": "sha256-izAUGsNNJNghrhVrBxoNjAG5gT7DOzdKOpuLikUCWD4=",
      "url": "_framework/System.ComponentModel.Annotations.vvt1z45s9p.wasm"
    },
    {
      "hash": "sha256-AJUJp6jvHdMDa/u82UMpUPx6LTMEf24sa9fPhIuMK+s=",
      "url": "_framework/System.ComponentModel.Primitives.oufnh5c58z.wasm"
    },
    {
      "hash": "sha256-6Xxg+HMpbk2hURISiWQiObSNASggdWcq5rZhxmX6W/I=",
      "url": "_framework/System.ComponentModel.TypeConverter.bzmj804haz.wasm"
    },
    {
      "hash": "sha256-Fh9RRxywridpeqVqz+oAuOgPH3xpOkh7CIxx1eL+FQs=",
      "url": "_framework/System.ComponentModel.ydqem3mmyz.wasm"
    },
    {
      "hash": "sha256-MNGXGFl8cRNOJTH4TwRWbm7/VL1GJPV+hwPXnMebC+U=",
      "url": "_framework/System.Console.0o5i8nepel.wasm"
    },
    {
      "hash": "sha256-61Lo6N1rjMlZ//frS6Hhmm4kel76xlKmvmJbfCUOEeo=",
      "url": "_framework/System.Diagnostics.Debug.3mluqcsftw.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-nGjUaVHyjfc2K1Rjam+1nMQpdp8fmTKJBcmoV6TXfkk=",
      "url": "_framework/System.IO.Pipelines.gvnbjefpez.wasm"
    },
    {
      "hash": "sha256-Le73dSkT+w2Xf2u69u2ZRqEgE3h93x/1xD0BOt3j0ec=",
      "url": "_framework/System.Linq.Expressions.jk37g54ijd.wasm"
    },
    {
      "hash": "sha256-LBDTZWhv6HIs5Z2mfSY4XbObunKgdeCXgw6vkzNf9sE=",
      "url": "_framework/System.Linq.wzeltplxct.wasm"
    },
    {
      "hash": "sha256-OQG+daCMCkKaJY1Zuv6Ex0hqmrfN4QEPqgZxcPofkf8=",
      "url": "_framework/System.Memory.3l9dleem56.wasm"
    },
    {
      "hash": "sha256-5HABXuXKTqhZEkfnPOx1cqHIMDjM8o2osiCOZCOw1bE=",
      "url": "_framework/System.Net.Http.gptia4f19s.wasm"
    },
    {
      "hash": "sha256-hEcQQHk3niX++ZCLAWqYNOJQJYfMHW4/1K0TJhoCNSQ=",
      "url": "_framework/System.Net.Primitives.ky2a7d5ird.wasm"
    },
    {
      "hash": "sha256-6lyWA1G676ckHdIbWTvXaI1jhlme1OrNrNheaX4jkyU=",
      "url": "_framework/System.ObjectModel.uv39dtmf9t.wasm"
    },
    {
      "hash": "sha256-m1BGdv50rP94dv6750VtB1JT41BbAZ6/K4Wc0+t8csg=",
      "url": "_framework/System.Private.CoreLib.bgpnchk3xp.wasm"
    },
    {
      "hash": "sha256-UwfLo8ztxDwKePlSKfst5X88+vHl/YGnhv1AvriN2yM=",
      "url": "_framework/System.Private.Uri.n70dhhjwjk.wasm"
    },
    {
      "hash": "sha256-KvUgfqXFDVSf8ryfOmWReuadFbA+SotfNIh0HfkK0XI=",
      "url": "_framework/System.Resources.ResourceManager.64k8v5ksx7.wasm"
    },
    {
      "hash": "sha256-uaQxBfWt1JSSdhLoBZWOTpho06FVn25VSjCwnXvCR7k=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.feozdik0jm.wasm"
    },
    {
      "hash": "sha256-cet4jiTSvwiNc1TJcR2C3IikTUog8ocXRyl0tlbFhwA=",
      "url": "_framework/System.Runtime.b5tkghh9ld.wasm"
    },
    {
      "hash": "sha256-xMMv8swJqll+3CA+hMoc7o/OwXNLu3zdhSeJ4MmgNvM=",
      "url": "_framework/System.Security.Cryptography.09sfvedl29.wasm"
    },
    {
      "hash": "sha256-1Sr3NN1aQOE+1F8G3kwzVbHdwDRQg0a4RktpKJRmuls=",
      "url": "_framework/System.Text.Encodings.Web.pnw29cwzej.wasm"
    },
    {
      "hash": "sha256-XU8uO5s4JN4dFOpKguGONlRmw8t/iu6G5yspDOZWajY=",
      "url": "_framework/System.Text.Json.dgdxxro4zd.wasm"
    },
    {
      "hash": "sha256-Fx76KSDTO70SPujMRoHB/LVq7nVvLqp/o0laGcECYBI=",
      "url": "_framework/System.Text.RegularExpressions.7gtc6ahfbj.wasm"
    },
    {
      "hash": "sha256-CbkwZykPvNpH2pDoQBsjVo1zbL2FDpLNPrFtTdem6fo=",
      "url": "_framework/System.Threading.Tasks.h6ysxjzsyl.wasm"
    },
    {
      "hash": "sha256-319B7WIXJ7ZD6SZ1l7es3CoglOLgv5lKWx0Ew9mli1c=",
      "url": "_framework/System.f0t8bkq7p2.wasm"
    },
    {
      "hash": "sha256-PmCwet//bhYmSSworaskC/VrCBzqV1eOUq+lMhMkdCU=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5A57FxzcJRwpIrn/eN+NeAKcVHW08gXRk0i0BDM4TDE=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-oksVqHEW5dic8ULICrYkuUVNascZfAw7ZPMG45TR/ak=",
      "url": "_framework/dotnet.native.6m0hb3g78a.js"
    },
    {
      "hash": "sha256-o2x4vkXl29AT7+ydjSBFXzuxrlVCqlbu0dnKYeMk3RM=",
      "url": "_framework/dotnet.native.zw8ib5pvmp.wasm"
    },
    {
      "hash": "sha256-W1NVCHdXLsZwmcxPLLatkJOSnfn1UNne6uSpSi63ozM=",
      "url": "_framework/dotnet.runtime.7laf4z0i7i.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-dZgCSai+MsFH3pvdNloi30rEA3hjUnL7I5+saY6meY4=",
      "url": "_framework/theonlytool.tu20y2m6pb.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
