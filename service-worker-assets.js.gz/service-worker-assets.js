self.assetsManifest = {
  "version": "0cP18/Db",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-a40UIv3hb7kG3hB68F+sKhPGxJS67pHWMyMf5CDV2Bk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.np171i6081.wasm"
    },
    {
      "hash": "sha256-I0thslpDwf6AW+OXg1qMErQnYtc7sFevDIiCiN8jzxc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xvip1qkk01.wasm"
    },
    {
      "hash": "sha256-wZa1DMP2WAkgFRNWZ4ym5VBjlZO7oCZNRHkKRVBJkOc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.h8x6xieu1p.wasm"
    },
    {
      "hash": "sha256-3ZhMxXTrP8WeUbB45FPozlm5cL/1Rwd/cAy3im220Hk=",
      "url": "_framework/Microsoft.AspNetCore.Components.bihuryf4lo.wasm"
    },
    {
      "hash": "sha256-euicIGuRtoH3vHn0vB74beTqZRef2iz5qZAK7LjO3/U=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.eucmlijtq1.wasm"
    },
    {
      "hash": "sha256-2HCQGTzfnpdkwdDSM/e5FW3GiluFy0rNKR2HV6WPN1k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.szd8gqkev6.wasm"
    },
    {
      "hash": "sha256-Ozv4gMHQPG5XXVtvDQUvBpnUH6j+vq9/45wZekUrd8Q=",
      "url": "_framework/Microsoft.Extensions.Configuration.f7befnyrwi.wasm"
    },
    {
      "hash": "sha256-JWT+s2jQ8iGggm6mBYG7e2UqPMCMuUvXgtarzvUPBnw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.jm7xrfuq0c.wasm"
    },
    {
      "hash": "sha256-HXUWgCZtXDO/sSVxSkCZJdjEXnUk6KMMeBO9ZlKpiXE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.v55fvldks2.wasm"
    },
    {
      "hash": "sha256-UgXXyRgFkkJS38hamfUWa9DPXyspNA4RDLclW8veHAo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.y4mlmzabky.wasm"
    },
    {
      "hash": "sha256-AD5e+CWsrOKbqVFFNElwidXwS261kGzE1mvTOoKHvcE=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.wwq7ivp6jx.wasm"
    },
    {
      "hash": "sha256-1X79eONdsArLAp8OTgbc2DFSkTX0cPz94UhRCo+J40g=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.bkpr3tlsmz.wasm"
    },
    {
      "hash": "sha256-dNLfJzB42NsWeRex8cVTc08eVsAavTNRxvYQ6+FjAus=",
      "url": "_framework/Microsoft.Extensions.Localization.se6w6ln9te.wasm"
    },
    {
      "hash": "sha256-1U/q4/8BBBl6YbB2II+J9IlUvC9ZoXxk5Lw1c5Mz2+A=",
      "url": "_framework/Microsoft.Extensions.Logging.5gd7ouolak.wasm"
    },
    {
      "hash": "sha256-7iRdjpMuiLoF9WyzYcjEHHjwO63JojVWl8vewKzmmBo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ukkjar6p18.wasm"
    },
    {
      "hash": "sha256-t5cBgPFlV3vwzclaQHzWtEFh6fT33niTpW/dXEhLiEQ=",
      "url": "_framework/Microsoft.Extensions.Options.9w0jdgj9rc.wasm"
    },
    {
      "hash": "sha256-719WV5rSfsOcpJCXKj4s9XF8AFZXelDD4+Bj/w70wYI=",
      "url": "_framework/Microsoft.Extensions.Primitives.920zhp4nb1.wasm"
    },
    {
      "hash": "sha256-BD1diJ8S2ur/MQHb+AlCIfke7yG0ka5hSvRS4JicbT4=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.81x7gcy5ss.wasm"
    },
    {
      "hash": "sha256-1qAWocex/xrFk0ERP8VHgKvczV5gBQlZjoBuyH5sGDk=",
      "url": "_framework/Microsoft.JSInterop.iy1pdjritv.wasm"
    },
    {
      "hash": "sha256-4ihOmolI6uZ9uIZC/60SO3iwBYCroJ4pdWZDbTlXZR8=",
      "url": "_framework/MudBlazor.iciw8z5tpp.wasm"
    },
    {
      "hash": "sha256-K7q2JAnXeOmXhf5ZiKKwfOFTQqJqd7JdhQ7IcBprIsE=",
      "url": "_framework/Services.Base64.5kspldavqi.wasm"
    },
    {
      "hash": "sha256-8BJvyvswywW/VvYUTGFJ+pa4fK0BKkNmcUM0/BK5jLY=",
      "url": "_framework/Services.Hashing.47tt87v565.wasm"
    },
    {
      "hash": "sha256-Kt/7/T6gtHzlUt8YSqcBfHwTyP0ivvv9GaOBkuO+lF0=",
      "url": "_framework/Services.Url.yhhpc8pj6r.wasm"
    },
    {
      "hash": "sha256-l7KKLXAZrli2mP1RK2BuESUQXFnXG3IAwanwaWlduew=",
      "url": "_framework/System.Collections.Concurrent.x6vi7e0ew2.wasm"
    },
    {
      "hash": "sha256-8ws2IqXiwUGejAvJsVI6Y7wcUrYmMa3rlNrSG+X5JZo=",
      "url": "_framework/System.Collections.Immutable.1fzrgyrif7.wasm"
    },
    {
      "hash": "sha256-xOjXuqKUknHExQjePVzZGOk26u4AkuntkITJSI9O9TE=",
      "url": "_framework/System.Collections.cs8fp1mi21.wasm"
    },
    {
      "hash": "sha256-BGtNEya8g5LRU3D4+Cv0S9y2ExjBXUoTL+CGcatxZlI=",
      "url": "_framework/System.ComponentModel.0ztds8sx2q.wasm"
    },
    {
      "hash": "sha256-9o42Ei742+FE+iFrNQAizKL/G/CuD1hEhojFJuykPJU=",
      "url": "_framework/System.ComponentModel.Annotations.iddx5yijvu.wasm"
    },
    {
      "hash": "sha256-HkqOd88AibNtrFBd79P95cs65S30eaqpVHbdzdDRsOQ=",
      "url": "_framework/System.ComponentModel.Primitives.myobvibpqu.wasm"
    },
    {
      "hash": "sha256-eux6sZ8FPuWRl9h+s9TFHmpUgSzwe1+nzEO/0hp+NAQ=",
      "url": "_framework/System.ComponentModel.TypeConverter.ar3a6j7qy7.wasm"
    },
    {
      "hash": "sha256-ki7613YJx8KoRVExMn5FTnRit2wD90XDhmzfBPkzn7U=",
      "url": "_framework/System.Console.66l1ggafci.wasm"
    },
    {
      "hash": "sha256-QgflFuW5MhyydAElDKe0HaScU+HXNnqig8leKqZM/gA=",
      "url": "_framework/System.Diagnostics.Debug.ib2wdap4fn.wasm"
    },
    {
      "hash": "sha256-L4IyoCLhGeSvZB8hTJT4ZmOfcl6QSPC4w6gqJhZoS6g=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.1cuhyag8s0.wasm"
    },
    {
      "hash": "sha256-EfiALOSnWO3tFf3TeA8+wqFwxLORhsRdk2SpkrRMwe0=",
      "url": "_framework/System.IO.Hashing.zfjm85scgn.wasm"
    },
    {
      "hash": "sha256-ONdA7TFavpxETEDw0EnrHygQp2nj0mbbjodYTHJ5WIA=",
      "url": "_framework/System.IO.Pipelines.0ukn2jmtqo.wasm"
    },
    {
      "hash": "sha256-p9wQwk0MRS1AzoAJRyMCTwBmsvCMraQCI73g4ylcDQk=",
      "url": "_framework/System.Linq.Expressions.3p2cc6my15.wasm"
    },
    {
      "hash": "sha256-IxfKfuTHZLYYCphmA4+MQD2VGkf82SGAjYOC9OGSUCk=",
      "url": "_framework/System.Linq.rqixezkzf2.wasm"
    },
    {
      "hash": "sha256-ka/oRvpnDQQ+b+mZLueVztcM+gIaAJ7T3OKIuhgNabo=",
      "url": "_framework/System.Memory.pq91g27ky0.wasm"
    },
    {
      "hash": "sha256-eI/PHaEZwmFOu3YB07jgXGM4o3xiOo+SrGhMZeoab/g=",
      "url": "_framework/System.Net.Http.45ohjux7g2.wasm"
    },
    {
      "hash": "sha256-aujX+uMh/RSX68wGQGHBUGmTYi28iOGwx8Y7LEGzpkY=",
      "url": "_framework/System.Net.Primitives.25ibrzs7a9.wasm"
    },
    {
      "hash": "sha256-rOzQxU0739qWGPKr+LYtcA4raAbSYVO1wYACMSg51wg=",
      "url": "_framework/System.ObjectModel.0ptwxde3mn.wasm"
    },
    {
      "hash": "sha256-kV6VO//PtARTfUDW5SYqJaiXjp1EdgsS2AgI5eN/A0w=",
      "url": "_framework/System.Private.CoreLib.9mjx1jj2j3.wasm"
    },
    {
      "hash": "sha256-FcWjuLLyz+8mf+U+nw6ca6HrelPhdBtwlVnRptyqM9E=",
      "url": "_framework/System.Private.Uri.t2rsp1z7t5.wasm"
    },
    {
      "hash": "sha256-zUN9jnFMnFFl3MQDHBFHqLmJ7NltmuofD43YClYwNI0=",
      "url": "_framework/System.Resources.ResourceManager.pd6adydp7s.wasm"
    },
    {
      "hash": "sha256-RntDvhNGf7pL40fUimlT/fKwvv4MGtTFN8UrcY38fdI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.6kbzeq6yct.wasm"
    },
    {
      "hash": "sha256-VNK5CL5fLM82C039DqhjkySlNI9ev1BNUeJ3npgt43o=",
      "url": "_framework/System.Runtime.ofqyktb1o4.wasm"
    },
    {
      "hash": "sha256-jn1KgSJF8ky/GekSEh3M/whyKi2IJyXqNdxk2hiuZ5U=",
      "url": "_framework/System.Security.Cryptography.qqvj36iust.wasm"
    },
    {
      "hash": "sha256-7YsESoBG1RCCl1SVYZwwevmXllOHEOF+KNtsvpG6asE=",
      "url": "_framework/System.Text.Encodings.Web.vp701vtodc.wasm"
    },
    {
      "hash": "sha256-lm/GZDuXqblZYso0Z6eTYrGBLS3gzGLVN560Gp+Zfvw=",
      "url": "_framework/System.Text.Json.i98zjuj8jt.wasm"
    },
    {
      "hash": "sha256-c4UyLUqXcVnQ2M8D2jupvlvOpZ9KlXiQH9mZbSbS/hk=",
      "url": "_framework/System.Text.RegularExpressions.1rkueiajcw.wasm"
    },
    {
      "hash": "sha256-MeJZ/nGUq2rpAiOXpwD9t6/z/eZiB3vnf2MvmyMx428=",
      "url": "_framework/System.Threading.Tasks.jrnemeu4an.wasm"
    },
    {
      "hash": "sha256-5x3GPplpN5WBojtNwBjuek2x2TSs+aU9Kqx4NhXREXU=",
      "url": "_framework/System.l1ekyr7hdn.wasm"
    },
    {
      "hash": "sha256-6YR6YV3VzrAFSKiuLnYdaBnMyVCkkfyeQdjHTI/HvNs=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-iLDi2PgLsDGL/sJmjQYorsfOKR0qZO2Sw4CxPO15JRQ=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-1feL7t30WjATvx7ccZ3reeAWcqfCss+zjzIz7J+TVuI=",
      "url": "_framework/dotnet.native.1t8lwibe0f.js"
    },
    {
      "hash": "sha256-98MkTi1v3jkQVitwgaAKa17PiWVOcvvHSeqk9GicAag=",
      "url": "_framework/dotnet.native.ngy2llg0wq.wasm"
    },
    {
      "hash": "sha256-MbxvjQiLd0brZSb4DHed2hQtAF5pbvZt/KJigzjZ70w=",
      "url": "_framework/dotnet.runtime.33y5wagaqd.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-1nhSp2usjdlW2bRbCg5wlscHwuWn9jygEM3B2BBBsoc=",
      "url": "_framework/theonlytool.yhl8aojub6.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
