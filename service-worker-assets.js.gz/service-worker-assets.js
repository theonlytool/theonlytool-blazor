self.assetsManifest = {
  "version": "f89F00ni",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-Ao0IIi9K+7vFjCb3mbeWXLCBr6TGYccNlKpZftqDqjc=",
      "url": "_framework/Services.Base64.eotbsbe295.wasm"
    },
    {
      "hash": "sha256-M9UtAR7s5mfBnhgw0tjf6KNoag58LjwKpLJ7wbCrnoI=",
      "url": "_framework/Services.Hashing.le4ae6tahs.wasm"
    },
    {
      "hash": "sha256-Spy0xHY8/Z4sEg+Q6WzvxjypmHYFpgIzJ8Er05a9BkY=",
      "url": "_framework/Services.Url.iybrj19wcl.wasm"
    },
    {
      "hash": "sha256-c/5Z8h/RcNvp+KcXxd02m5HoLA5YH/Z29788HjuKvfc=",
      "url": "_framework/System.Collections.Concurrent.91qzzk4yq3.wasm"
    },
    {
      "hash": "sha256-7QWvL7oJFmJNJ6IgOj7bhCnpFCQANHp2Y0Xx4OCK6Ys=",
      "url": "_framework/System.Collections.Immutable.dwqjr70225.wasm"
    },
    {
      "hash": "sha256-qHGL9gCnZ3RzDn5Z84ChgFHM2ztVQrXPRgiwa37uchE=",
      "url": "_framework/System.Collections.ocu08kgchz.wasm"
    },
    {
      "hash": "sha256-KQGUDFCc4qSHISJThX7qbRFp5nOi+vVf6coW4AmcO9o=",
      "url": "_framework/System.ComponentModel.7celnv3t3i.wasm"
    },
    {
      "hash": "sha256-taes1pwDpoRYMeJaWYjYclQnzFUV91mVaMM4kw+9gNk=",
      "url": "_framework/System.ComponentModel.Annotations.15sptob8ol.wasm"
    },
    {
      "hash": "sha256-jXWncB2sddO4FXLQKFbM3JKC0nWW+oyhEesLDJgDDP4=",
      "url": "_framework/System.ComponentModel.Primitives.n7ixsh38rh.wasm"
    },
    {
      "hash": "sha256-cM9FXg9RBhSurE73JLsw+7TaiKIZgqBqHSNoBRG881k=",
      "url": "_framework/System.ComponentModel.TypeConverter.00554pwgoa.wasm"
    },
    {
      "hash": "sha256-kfVm5DPsDu52aQpAlhqQvNmpX00QEz3kHj+Y900TzRs=",
      "url": "_framework/System.Console.9qmasys9mr.wasm"
    },
    {
      "hash": "sha256-4Y33J2ZHkF1k+dPGwvFypu9o9wiUjMMV08lBMc5LD8A=",
      "url": "_framework/System.Diagnostics.Debug.p2sveg6uyy.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-ciRu0RyXxUuZXjSDQRfB+7og6z0BYkFinNLjUinkr6s=",
      "url": "_framework/System.IO.Pipelines.egci0jm58s.wasm"
    },
    {
      "hash": "sha256-bfLtWJ7hcOOFIP8vXj6Yt/A75rI3MvlkF2X9U/FRj/w=",
      "url": "_framework/System.Linq.3kwzesk6de.wasm"
    },
    {
      "hash": "sha256-xwXW5IDb+m4iIqmq5FCDZI5NZxg/zhYc0IH8Ydxc2/g=",
      "url": "_framework/System.Linq.Expressions.vye8czhk3i.wasm"
    },
    {
      "hash": "sha256-lDx6h9MG3iKf+bzn4v6qM21+PgpQDfZsm1OvZxWDWH0=",
      "url": "_framework/System.Memory.km8zdgoj5m.wasm"
    },
    {
      "hash": "sha256-eAl2nWTXvyTq87X9AN7DM570iIVhKX7HriQvfHFHihc=",
      "url": "_framework/System.Net.Http.osga3snhna.wasm"
    },
    {
      "hash": "sha256-8pcsMDQz3YsG1X4CeIVlWLf3N7VOfymFKQy74tPUPf8=",
      "url": "_framework/System.Net.Primitives.ux3clhmytu.wasm"
    },
    {
      "hash": "sha256-hLueTUykypbeP2CiUf2RzuK3ivgP8E6hq11AcuBnZOg=",
      "url": "_framework/System.ObjectModel.g386a7tp5d.wasm"
    },
    {
      "hash": "sha256-gipoRijy+KpHQTtBW9AjzFTyh4t+4zf2dg98oSzlnpI=",
      "url": "_framework/System.Private.CoreLib.aus6nzz1ca.wasm"
    },
    {
      "hash": "sha256-ipIgyhYD60tk5/AYHsxRMa5x4VNTsNtAnzyjBwIpx1M=",
      "url": "_framework/System.Private.Uri.qso4g7bka7.wasm"
    },
    {
      "hash": "sha256-DRCgvkwEXulZiDdnJWit2MtYYQVNETDoeFfa4PiIuZA=",
      "url": "_framework/System.Resources.ResourceManager.t4q7stmkg0.wasm"
    },
    {
      "hash": "sha256-5cGZaC9zuo8UdqDpSGIi5BuSiJilace+K+OPH9TcuDs=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.h99kmkbcyg.wasm"
    },
    {
      "hash": "sha256-7Ghd7c1HoNy+SFcZAhBd0xLbf1gZfDnE2YJuIP+azg0=",
      "url": "_framework/System.Runtime.cq68flq9xh.wasm"
    },
    {
      "hash": "sha256-RGd/JyHqFKXjt3tPg/UDHWKV/icDRjTA9EIS5VNhBvI=",
      "url": "_framework/System.Security.Cryptography.8lcwpaj12s.wasm"
    },
    {
      "hash": "sha256-m2HawUVsFEYnw/aEDg8rIqgq+GYGUBj0V/H8mG1CRjs=",
      "url": "_framework/System.Text.Encodings.Web.fnl0o72t9d.wasm"
    },
    {
      "hash": "sha256-W6iWPZmiWxNFzsFWO7fMsuydU0er9gskuEt2DlS3wMQ=",
      "url": "_framework/System.Text.Json.v3x75s3ble.wasm"
    },
    {
      "hash": "sha256-IG1a0zoBF/S1SfPcKxrmbKRgoK4eMO4Qr7j4fVftA3o=",
      "url": "_framework/System.Text.RegularExpressions.ctwjm44bgk.wasm"
    },
    {
      "hash": "sha256-druZ9wy8YYfYdtwPbxKQpiOjWtt/Iq215HaPVZBBMjk=",
      "url": "_framework/System.Threading.Tasks.awcls9r8pe.wasm"
    },
    {
      "hash": "sha256-ezYyOdV5UZyKZd1bqnQFVWPhxDJRKyRLdNJD/Wv5oy8=",
      "url": "_framework/System.pvl3sv0rb6.wasm"
    },
    {
      "hash": "sha256-NqiTU1uCaQpbFUULT9ZWVKcQBkHpVumHsq2Y/eOg6ZA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-iLDi2PgLsDGL/sJmjQYorsfOKR0qZO2Sw4CxPO15JRQ=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-1feL7t30WjATvx7ccZ3reeAWcqfCss+zjzIz7J+TVuI=",
      "url": "_framework/dotnet.native.1t8lwibe0f.js"
    },
    {
      "hash": "sha256-98MkTi1v3jkQVitwgaAKa17PiWVOcvvHSeqk9GicAag=",
      "url": "_framework/dotnet.native.ngy2llg0wq.wasm"
    },
    {
      "hash": "sha256-MbxvjQiLd0brZSb4DHed2hQtAF5pbvZt/KJigzjZ70w=",
      "url": "_framework/dotnet.runtime.33y5wagaqd.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-yhGfP/Y5Ym1/eKn/SUMuoXzUxjaxT9bTjLeyuIwcF5o=",
      "url": "_framework/theonlytool.m159kjxb8a.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
