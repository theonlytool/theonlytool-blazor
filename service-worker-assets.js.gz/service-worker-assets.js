self.assetsManifest = {
  "version": "rClAX29B",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-h0azHXZ0Jz5szbrFYwHBObMEv1Xf166lpug6riGUbCw=",
      "url": "_framework/Services.Base64.jtyth4rgx1.wasm"
    },
    {
      "hash": "sha256-wPb8CjY6OM8xzqNhTqEPXoO9Vfs5T6JbMtNgkowACuE=",
      "url": "_framework/Services.Hashing.knzdhg1kd3.wasm"
    },
    {
      "hash": "sha256-Le0Lf9M2MwcbWmlVgh+O8FVirrFsvDMwLWvYvNTsU0A=",
      "url": "_framework/Services.Url.5ymsyiun9f.wasm"
    },
    {
      "hash": "sha256-EXP1Q9HXQyKvifL/lVMIbaXRiGn2/IdRZOE7eKkK0/4=",
      "url": "_framework/System.Collections.3n3mhgeo09.wasm"
    },
    {
      "hash": "sha256-Al+Zd4N6pMcCmon0dQ9ZnR1TULk4XEiA///3R4mZh48=",
      "url": "_framework/System.Collections.Concurrent.iw746yplzf.wasm"
    },
    {
      "hash": "sha256-DvinVKjPE9IYGrPhnMV2xSA7JSKHJDzRssnWeJJKkHE=",
      "url": "_framework/System.Collections.Immutable.y7zrpph99o.wasm"
    },
    {
      "hash": "sha256-CgP0WV9UJ7l99X7BaDWHFGXi5AXGkXuKAFXxTtklGT8=",
      "url": "_framework/System.ComponentModel.Annotations.m971k5qjjt.wasm"
    },
    {
      "hash": "sha256-JJ8J15l+DAHluVEWNzOKyu6wEi23XrWt1/3BPKwigcw=",
      "url": "_framework/System.ComponentModel.Primitives.o1asrtfvmu.wasm"
    },
    {
      "hash": "sha256-am9mDbunQD5sqw5vTVjs0IroWn5VCB/OYVODjbcdT7w=",
      "url": "_framework/System.ComponentModel.TypeConverter.en6zv57trz.wasm"
    },
    {
      "hash": "sha256-X3UhzHQ8oPw+1gIAtrUd6W8sed1kmYYoxOaMl2S3kZw=",
      "url": "_framework/System.ComponentModel.jzuedxd7v1.wasm"
    },
    {
      "hash": "sha256-imu++9qYs7prPR7Fio1hF63QQuw3vXPJouxk0vk39wI=",
      "url": "_framework/System.Console.mprt6tifab.wasm"
    },
    {
      "hash": "sha256-BT+tg08bPPpa+OSbkt/xgHEgVKwl9p9dNRdjxZrZIGQ=",
      "url": "_framework/System.Diagnostics.Debug.58a5g7335u.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-F7eq3vfkNdyf7BI0RJMCuDGtdhNgu4qn1GGWK5FvVz0=",
      "url": "_framework/System.IO.Pipelines.hqvxmp1tnr.wasm"
    },
    {
      "hash": "sha256-1tVzj8MAtxY8OEk1HzWwdfT1nYTh6V5mi18J/QgBQqA=",
      "url": "_framework/System.Linq.Expressions.2tc87n0332.wasm"
    },
    {
      "hash": "sha256-UEzhneCAB4+9HfVVw/dDJz+ORNAa+9C+27vr4HL9Dko=",
      "url": "_framework/System.Linq.w48aot0jh7.wasm"
    },
    {
      "hash": "sha256-pPVE5nsXj4HrJ4moCqkfEx26gfgWgVTSPGhQFDH3Wh4=",
      "url": "_framework/System.Memory.0fcq9okwhr.wasm"
    },
    {
      "hash": "sha256-XP63du6nwaOXst/7QNT0RJhOpRGDUdETMwrDv2bjD2w=",
      "url": "_framework/System.Net.Http.wpsxy4knhi.wasm"
    },
    {
      "hash": "sha256-54Sidp4aqYDTQI7b6YP4U9grUXaiD22W/I5OwHoJgqU=",
      "url": "_framework/System.Net.Primitives.d7pahnbjlt.wasm"
    },
    {
      "hash": "sha256-zAV3m17jZEpKcLvLUSQOd8vDBpzIVkgIXme9txCbnXc=",
      "url": "_framework/System.ObjectModel.wr2jpizcb1.wasm"
    },
    {
      "hash": "sha256-yX5vxwKShrpI8xNutN3yc21tQhMF4VQxtdLx9+HqrSg=",
      "url": "_framework/System.Private.CoreLib.p4aesqlvh7.wasm"
    },
    {
      "hash": "sha256-v6gGC1M6QAbfQWV9ZLj6FcWQmaZ4j5Aaujpxc5PlypU=",
      "url": "_framework/System.Private.Uri.1ct7rrgyvn.wasm"
    },
    {
      "hash": "sha256-lAa6kJ46JdGb+908ctDwu8JdnRUQ7c1kfu1CmLV2Fx0=",
      "url": "_framework/System.Resources.ResourceManager.4ags80juje.wasm"
    },
    {
      "hash": "sha256-rNzWhBOFDey9RsCv9RYwXjilGSxT7OPih9Pom7VnobY=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.8z290vppku.wasm"
    },
    {
      "hash": "sha256-Nv+HR93itPPACTk/1uhnXEJtIr6qMDBVmZm0oJAkstE=",
      "url": "_framework/System.Runtime.efi6ad4q2u.wasm"
    },
    {
      "hash": "sha256-xgYCrEhJUlImzdBPlPalWNaLDdvWlNJfUgU8vIb7LYg=",
      "url": "_framework/System.Security.Cryptography.2p48hb4ls8.wasm"
    },
    {
      "hash": "sha256-oAvGjE7zOfELanuhXBazvipywX/fnbrfBmWPDH/R3bw=",
      "url": "_framework/System.Text.Encodings.Web.8qvkegu1ci.wasm"
    },
    {
      "hash": "sha256-4+uNIrswj+zaLfuHWyxzohxo9iGY1+Td4fbXZRiw2uY=",
      "url": "_framework/System.Text.Json.tctmyxh1dk.wasm"
    },
    {
      "hash": "sha256-4+MWffQyDZCJ8hwk0jpBpQiNPr/kYEsFLIXpt03tmJI=",
      "url": "_framework/System.Text.RegularExpressions.xj5knbwhob.wasm"
    },
    {
      "hash": "sha256-vKm32u+HCbVkLv23h0l0UIaX6nZqQRZ/w1Ya4zP2QWU=",
      "url": "_framework/System.Threading.Tasks.0facq44j7y.wasm"
    },
    {
      "hash": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
      "url": "_framework/System.t4d4s3f398.wasm"
    },
    {
      "hash": "sha256-v1UTF4VrhZHYxKU8T4k6MVmZkcb6hhn1D7MJpYvcATw=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-p9eEzXhQIsI0a5bBJhfzW15iRafgplTxT8XrO5FiH9o=",
      "url": "_framework/dotnet.native.noby4tlk4d.js"
    },
    {
      "hash": "sha256-Po2dalLvTpf5jAS+jt0TzuBYybYiL1F6qAacZJ8UAdo=",
      "url": "_framework/dotnet.native.qe75a9vfqn.wasm"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-A0z5zJwHCgxmbhaHJFpOqr7Xkuc0xoM9SrxtSCQbuyY=",
      "url": "_framework/theonlytool.raszy815t0.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
