self.assetsManifest = {
  "version": "iLdDtJ7E",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-osxAfYS8WEne2oYuV/MP28HbXVy3VYUktbma9IaizKA=",
      "url": "_framework/Services.Base64.i3u4ywijyo.wasm"
    },
    {
      "hash": "sha256-I9bxo+jmcppNcfSNE1gmMOxgR5qO1XhT03SSBJFFBhs=",
      "url": "_framework/Services.Hashing.n3iyq3shvy.wasm"
    },
    {
      "hash": "sha256-/Y0tBLmHx1VdE+BEYorhp+NORiqAjy7F2Q0oUjo5KZI=",
      "url": "_framework/Services.Url.xbtaj2q0ut.wasm"
    },
    {
      "hash": "sha256-rE33grgByGSHMbG9S+htpnUQ51k4Pc8Dl2vrp23VOoo=",
      "url": "_framework/System.Collections.0dw69gegcw.wasm"
    },
    {
      "hash": "sha256-Q/lkJ1XvgBgYUb1pOBH6rM3dNr4GYrlDtQbyC6QvMQU=",
      "url": "_framework/System.Collections.Concurrent.v1gcd03z7a.wasm"
    },
    {
      "hash": "sha256-dLU9bN2HnzM6KuDhc+tS0GfTMFYwGOy6IPtf+sTvSFk=",
      "url": "_framework/System.Collections.Immutable.4sog8z2dp0.wasm"
    },
    {
      "hash": "sha256-9IizJ3ZwW1jknG1XO+W7rctvq7Kp+WyfehIJM8hBq5w=",
      "url": "_framework/System.ComponentModel.Annotations.8t7ewaleoi.wasm"
    },
    {
      "hash": "sha256-/c1u9S8zP9APjE6LdbpcuWV21cmpVrzLJpOje7HGsh4=",
      "url": "_framework/System.ComponentModel.Primitives.xzfkgcwi83.wasm"
    },
    {
      "hash": "sha256-SjDfRTGSF2Gdk7M+0UZvxICN1cF/3g1gBp+W+4bE9/Y=",
      "url": "_framework/System.ComponentModel.TypeConverter.umcnww9g81.wasm"
    },
    {
      "hash": "sha256-YboxLhIZDLllF1V22SDdIaOouOct1Ov5rOylbb2UsJA=",
      "url": "_framework/System.ComponentModel.tt73s9dtdd.wasm"
    },
    {
      "hash": "sha256-crc7ddShk6fbJ5su5Y7MKzib8W2HvM/jowack+bzV44=",
      "url": "_framework/System.Console.q9zkpcni2q.wasm"
    },
    {
      "hash": "sha256-HAz93YCzPc4uMASHk0HEr2SF6KJhlw8PwREvqjp/d3w=",
      "url": "_framework/System.Diagnostics.Debug.0zv144ubym.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-agBw3O5EmksaHQ40qbBY3q5NCnjZ5BLESPOj69GnF8g=",
      "url": "_framework/System.IO.Pipelines.6l78wm3be5.wasm"
    },
    {
      "hash": "sha256-L905cj6+DgDGj7/kjq9Jb/Jrj65JWRGYVY5x9NEfqQ0=",
      "url": "_framework/System.Linq.Expressions.p2n0yjupsg.wasm"
    },
    {
      "hash": "sha256-dDgB57YEyE/phWPZje9vT2Xx+KSgsu/1EOspT8Vv4+k=",
      "url": "_framework/System.Linq.cwc5rj5e6l.wasm"
    },
    {
      "hash": "sha256-8zxUXh6kamX0tbgoPRWZqD4ltz+uJ/HiOppySsuCMK4=",
      "url": "_framework/System.Memory.le4jil2hhw.wasm"
    },
    {
      "hash": "sha256-V8qoLQbB/khh8BMNv84Qn5YP+urYRXmJgU5s0BwPQNM=",
      "url": "_framework/System.Net.Http.ngkjwz1def.wasm"
    },
    {
      "hash": "sha256-TQ57yanIpfdSS83FnKBn3HxPUSthPwJTM7jGjuKbHjo=",
      "url": "_framework/System.Net.Primitives.linpzmvv9q.wasm"
    },
    {
      "hash": "sha256-9F42Xn404nvsItUUn1/weUr365Da/NXjP29GqfaAkHQ=",
      "url": "_framework/System.ObjectModel.0nxnbrqz58.wasm"
    },
    {
      "hash": "sha256-5i+fHjgWLLa9WrKGPYG+MH6iQOH3rE4iDTSdL7E0G+4=",
      "url": "_framework/System.Private.CoreLib.qoiylqabar.wasm"
    },
    {
      "hash": "sha256-ly8OEwAhpXT8sGdwMzwiH6WpS8BtFw7PKrxzX9m5dWQ=",
      "url": "_framework/System.Private.Uri.haf0j83djn.wasm"
    },
    {
      "hash": "sha256-UAb7BXmE8ezFUAe0HTHqpkpW7wlEzwk8j+URbiTjhlk=",
      "url": "_framework/System.Resources.ResourceManager.477t0k64g6.wasm"
    },
    {
      "hash": "sha256-H1J53w/gZwL+Ux7rbVDTuyuEZeqeXusftWoVqutb34s=",
      "url": "_framework/System.Runtime.5vwqpvrd5d.wasm"
    },
    {
      "hash": "sha256-0TP+6/akHFjrHZGDv0NE7pmpxdrqqqaTLUUOURYuq9Y=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.fge8107jim.wasm"
    },
    {
      "hash": "sha256-bvGN/rrlvI/T9w+yydTgIc3y+lWMSN60yYthaYc/Ecw=",
      "url": "_framework/System.Security.Cryptography.ehqu52od4o.wasm"
    },
    {
      "hash": "sha256-PJnFgVKSoB0TNWJSfzXKHf8spBwn98YHVCFELdwxgR8=",
      "url": "_framework/System.Text.Encodings.Web.otlnnlesab.wasm"
    },
    {
      "hash": "sha256-58Fje4wk8rStyS5K6kSFWgVtIU4z+3eqovP4HF4BqgQ=",
      "url": "_framework/System.Text.Json.l90nppqeu5.wasm"
    },
    {
      "hash": "sha256-xSvjspmmInlfcnpzuzQpqxPpsZ1RAY4gRd4t8mF+v1k=",
      "url": "_framework/System.Text.RegularExpressions.hxl3ufyk7f.wasm"
    },
    {
      "hash": "sha256-veW/8CxzNGjjDfOM12sUMAlWxeB0GjM+qcH6mxrcd3s=",
      "url": "_framework/System.Threading.Tasks.nvpx16q0nk.wasm"
    },
    {
      "hash": "sha256-Nyi0mcDiCrrs35AL7vjBFsnr50PVmlZc0YGTCXg0h18=",
      "url": "_framework/System.p0vf5aoex5.wasm"
    },
    {
      "hash": "sha256-p/qtjE6y2qhG3dA0x63yJpAhdfpSRKBR1uNEc1LkSk8=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-6AErMlc7gMr2zQXq4dlYNko4OpIPM/DbMaBgNIXJoSM=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-KipEmnHVPv346PS6vLFDZJg+YeG/D3UYlHI9udpKOiQ=",
      "url": "_framework/dotnet.native.6sals8nuk0.js"
    },
    {
      "hash": "sha256-kWgios95+ALdV18qJt0zxX9zENxbF8ifBfdPhb9Vkqw=",
      "url": "_framework/dotnet.native.zzmgzj9wb3.wasm"
    },
    {
      "hash": "sha256-dLGiRHXW5dihGFbVNpFTz1UieVuaSP9FlFdtk0cxQFo=",
      "url": "_framework/dotnet.runtime.8ha609180a.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-/NyZjGlmLENC7m08xfx6/A/iKPTl5h6d9FI11B8bsZU=",
      "url": "_framework/theonlytool.csoq1bv1zl.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
