self.assetsManifest = {
  "version": "XiHv0Ztd",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-HXt5RmYlkHLWnyeJqqgnemFf17wcUWAmu6T7Wa0HAKA=",
      "url": "_framework/Services.Base64.js6229rlsh.wasm"
    },
    {
      "hash": "sha256-fzD88ksybJVmJ3SVOiM05+zjQxJC4xq7UXCgF5JL1EM=",
      "url": "_framework/Services.Hashing.jj85y5irgn.wasm"
    },
    {
      "hash": "sha256-8eR77q2gKQ24LDSReGAD7rXI4HQcIwkN6zWCYXhD8cE=",
      "url": "_framework/Services.Url.jnkezu413n.wasm"
    },
    {
      "hash": "sha256-ZoZ4y0vzTk5FJAiTrEFQBOY0MwS+fU5Hd6VtofAh5B4=",
      "url": "_framework/System.Collections.Concurrent.ablm14sie8.wasm"
    },
    {
      "hash": "sha256-ZMujjUhzn+72j9hYOdV8Umd64SnQAqh6VZkGvQMdelo=",
      "url": "_framework/System.Collections.Immutable.s4jrvfcbhz.wasm"
    },
    {
      "hash": "sha256-Kywek6hKhB+x8qXklhR3hUyX4X5oMjJKNeqYhbo5N0k=",
      "url": "_framework/System.Collections.prf43m75vm.wasm"
    },
    {
      "hash": "sha256-PGtsYnHAK0JIduyCVNcTWv6N/86AiQqMdMzD0PWt5LE=",
      "url": "_framework/System.ComponentModel.Annotations.gruad1a9u6.wasm"
    },
    {
      "hash": "sha256-YnnIyAtyCiltvOTpTYJeGluEhUbSMMdePT4q2s6ewTg=",
      "url": "_framework/System.ComponentModel.Primitives.ai1jrkm3wb.wasm"
    },
    {
      "hash": "sha256-V8TB7C9qw0DHB397CTHhPM1RC79uvI99MV+EW0550Oo=",
      "url": "_framework/System.ComponentModel.TypeConverter.p0djjcxzit.wasm"
    },
    {
      "hash": "sha256-yQDSFCIlXbqfv0DlqrFa4eUdlegHftxHiGmAVf5BRyk=",
      "url": "_framework/System.ComponentModel.fac0tpga5u.wasm"
    },
    {
      "hash": "sha256-PZk070YbRPgSuTeVdKup7fLjoo2wlE3p2OPYx61TB4U=",
      "url": "_framework/System.Console.x3b445tk8z.wasm"
    },
    {
      "hash": "sha256-oH/8K9Quvwr1xF/gHLSwAxm7MS7bipMU48lGELEqz40=",
      "url": "_framework/System.Diagnostics.Debug.8e6oun3adh.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-CanVWuvnie8m5xGa/F0a0AfsW5xhIL2sa6h8boZUlBw=",
      "url": "_framework/System.IO.Pipelines.h6uh29vsor.wasm"
    },
    {
      "hash": "sha256-Y6xxyghUecCGkQAs201im+zg17/1hIjttLif6u6mpDk=",
      "url": "_framework/System.Linq.Expressions.dcu88kjcp5.wasm"
    },
    {
      "hash": "sha256-xhyjI5dpqsIZL6FIdbJShnIloNcAM5mI+6c0/8YFfZE=",
      "url": "_framework/System.Linq.moxhw6mwjb.wasm"
    },
    {
      "hash": "sha256-Ms75aDpJW/R/d4zEL3h4NwE920hhLc3jlrDGkGZNWS0=",
      "url": "_framework/System.Memory.2gvwrzcdke.wasm"
    },
    {
      "hash": "sha256-QjACl8ze+VN4GsnsWZYIv1CYlsiOtnCxIqbZjn1JqJs=",
      "url": "_framework/System.Net.Http.2gst3arw3t.wasm"
    },
    {
      "hash": "sha256-EXaV6eCut14fBZGU53+bsBz0eO67ykeCWVGoNpiS1BM=",
      "url": "_framework/System.Net.Primitives.tdq6frnmpt.wasm"
    },
    {
      "hash": "sha256-78AmhAmA8r8W5HXMZHuVaKFQkjFwYuYKVVoVZQq0p7A=",
      "url": "_framework/System.ObjectModel.narjcl7hqk.wasm"
    },
    {
      "hash": "sha256-uJx0CC4legvxMSumKmj3rb1WlBd5Yl2nGZsrtaEP15M=",
      "url": "_framework/System.Private.CoreLib.sriltxfbbn.wasm"
    },
    {
      "hash": "sha256-WULz3fp6QsyT7xgho067edbdiTh9DTi2u0rSM1DpTSA=",
      "url": "_framework/System.Private.Uri.rjivi3py8t.wasm"
    },
    {
      "hash": "sha256-91xIUxqJkw5si6G02MPGSyDzGSiWVmAlWhfm8sk5T7o=",
      "url": "_framework/System.Resources.ResourceManager.bvxm0mvg3d.wasm"
    },
    {
      "hash": "sha256-gNHJDK7cciJTvbKVkr3kRqLROBhZNXjxk0K0F92k2cY=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.wowgk19gz9.wasm"
    },
    {
      "hash": "sha256-82h72GmXArRhe02mRnfdg7MXZGE0j5tfT6ScNOmOUcA=",
      "url": "_framework/System.Runtime.f1c04imrdj.wasm"
    },
    {
      "hash": "sha256-2bgOMT9R4a5UQfEc4AjZrvDuNtKVl1iKpySa1oov+cw=",
      "url": "_framework/System.Security.Cryptography.h633ixt19d.wasm"
    },
    {
      "hash": "sha256-LPizL+reODGXix9Mv1USpe2aPbBzNkq1jJxkuC974b0=",
      "url": "_framework/System.Text.Encodings.Web.44k0ayxuht.wasm"
    },
    {
      "hash": "sha256-2XyEGYIJseDGQ5ua/aqNUHn/G6cGT1HWHnScSz7lTaE=",
      "url": "_framework/System.Text.Json.vmbx6t7089.wasm"
    },
    {
      "hash": "sha256-ldXVUEwA2j2+nbc9aNyRF+UpmXWlXimLD+PLn4IELDA=",
      "url": "_framework/System.Text.RegularExpressions.vzeqconkpp.wasm"
    },
    {
      "hash": "sha256-Czbd+mdlakOcfHN4ibncHjcipTeJHTIHoVcr8Mkvle8=",
      "url": "_framework/System.Threading.Tasks.9zoyzdg7ya.wasm"
    },
    {
      "hash": "sha256-pJVfOQBBtR7pVRj/hsDjW2tSJr3eMSs6yVHVGbiVf2s=",
      "url": "_framework/System.ke1disal2r.wasm"
    },
    {
      "hash": "sha256-vKySGHsUI0EfhAEcPWOo59rWgZxWBPQbv0An6Tki6HA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-xpaEqK+6q7KPJMveudMVM+EW1z5NiC0WYHTVxVmEqiI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-jgmJHKTDZkqYH+tbs9FijgOzcdlK8XE/fg0FVI/ruU0=",
      "url": "_framework/dotnet.native.6buk8i5pk6.wasm"
    },
    {
      "hash": "sha256-9e5Vqt0u8nYMGCHU4JfYqrYQExAw3bgi5UYzATgvoJE=",
      "url": "_framework/dotnet.native.xto5am0qhx.js"
    },
    {
      "hash": "sha256-wW0L1H42TfMatybe1vKm/k57XP7qqXWX5r7AbCRx5JQ=",
      "url": "_framework/dotnet.runtime.pu7sbjsy59.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-b3v3w99VBnf+FZNoW2TIyUHiksJoqsYU0wNLbFb58As=",
      "url": "_framework/theonlytool.9ict00uz1z.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
