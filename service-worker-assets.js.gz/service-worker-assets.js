self.assetsManifest = {
  "version": "uUF/lJ2+",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-sPogIQccpJ7K+v3pEHM+rkWSkssYNV2t0OLW8dhjq0Q=",
      "url": "_framework/Services.Base64.4vr16bfkgg.wasm"
    },
    {
      "hash": "sha256-1JdJKaNcGFc7DBLPxUzTvApxkdF3W7zegL7PgRT2cZE=",
      "url": "_framework/Services.Hashing.kkrtrj09ei.wasm"
    },
    {
      "hash": "sha256-gKEnF/Oreo2TeBijj7JNvniaduxP6FN/YEgjEEA9vP4=",
      "url": "_framework/Services.Url.8277n24hi4.wasm"
    },
    {
      "hash": "sha256-dGQnwSmqrGHhp3e+QEFaUyebecwOh7uK3l2Ud8HP57M=",
      "url": "_framework/System.Collections.Concurrent.cwg8wh5p22.wasm"
    },
    {
      "hash": "sha256-lOpRfyd9Yts1Pax5cAUTMyyM0h6inXR6VcxrZOOHxss=",
      "url": "_framework/System.Collections.Immutable.wpfkynwppe.wasm"
    },
    {
      "hash": "sha256-rh6RDCByUCMtYjYUajXlkcirAglb+mbApDAdBgoN9rE=",
      "url": "_framework/System.Collections.apedbq4r0j.wasm"
    },
    {
      "hash": "sha256-F1rzKFPuBUzNyc5TT6Eg040PHrRLnexqKoC6lST0CNI=",
      "url": "_framework/System.ComponentModel.Annotations.l95xdk92fk.wasm"
    },
    {
      "hash": "sha256-DRsQPZRU5AKwGsjWQPiSGy+PbN1nlU0EI7i57AyUDoM=",
      "url": "_framework/System.ComponentModel.Primitives.by2get18g6.wasm"
    },
    {
      "hash": "sha256-ohYRF4W69ssggQtQqecSlIZIr115TvLjKzXweut+FDI=",
      "url": "_framework/System.ComponentModel.TypeConverter.yk3qi853ua.wasm"
    },
    {
      "hash": "sha256-R5Qa0ldAi8EJj4xKJE1FQwKYbw/CMedYSsshfyIHiiY=",
      "url": "_framework/System.ComponentModel.z5j9zy828z.wasm"
    },
    {
      "hash": "sha256-1CaxPYQ/WC+tDd1AMOwfHVMkvJFTIt8Fkip7viDHz2s=",
      "url": "_framework/System.Console.ccz96uc4x8.wasm"
    },
    {
      "hash": "sha256-y5NOJJkFqlRXeK+7tnM9f5S5GqSGBwnCoudd69Geb3I=",
      "url": "_framework/System.Diagnostics.Debug.3isu8kpddi.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-6Btj69AQZeup6rezAH8rqU0nyH+q7ndPlOtPCi7TpU4=",
      "url": "_framework/System.IO.Pipelines.ktrtiwmq0m.wasm"
    },
    {
      "hash": "sha256-PPzf7jjzw64JXCuFsv6MKdcwqkc8CEcYfgfouh42ALw=",
      "url": "_framework/System.Linq.Expressions.4maa0ufqpv.wasm"
    },
    {
      "hash": "sha256-+ws2gZT8qwYZz6XbuK7EmBu3I997qhnj7r9CXRkPueg=",
      "url": "_framework/System.Linq.rk1k706cf8.wasm"
    },
    {
      "hash": "sha256-QB86oJ69bBPiZS6cjAfeBYkwPe2SAXctEKByFCdki0Y=",
      "url": "_framework/System.Memory.8axdjlpwtu.wasm"
    },
    {
      "hash": "sha256-06rkxYTfrFlXyogu91PmHL9m9dyddnEfeRv+EQ+82b4=",
      "url": "_framework/System.Net.Http.ftvzb9fat9.wasm"
    },
    {
      "hash": "sha256-Zwek3nNLw12+76CXXyCew7wJRWgXDJn+Kim6rJY332I=",
      "url": "_framework/System.Net.Primitives.16gzwjvyds.wasm"
    },
    {
      "hash": "sha256-4XyDBamS/APt4BKpIlvW3XsGozccbdWpWmqVcTRnptQ=",
      "url": "_framework/System.ObjectModel.bdor3buc0u.wasm"
    },
    {
      "hash": "sha256-n6QiyvwETe4yma4v9uHcn4fCtRVoum5xi1iIjZVsHvI=",
      "url": "_framework/System.Private.CoreLib.72x1z59yr1.wasm"
    },
    {
      "hash": "sha256-fG0iZiiJvLbYi1C/qAHV8Hr8joPtCypKA2QQ8RAUzk8=",
      "url": "_framework/System.Private.Uri.01mc4pp664.wasm"
    },
    {
      "hash": "sha256-Vta7tINBxifJbPWH09pZFJeuaA07i2JrI+ZJkeqgcRk=",
      "url": "_framework/System.Resources.ResourceManager.ez79lhklaj.wasm"
    },
    {
      "hash": "sha256-5td/D8gkcqzhLVOVsdICiOyH+80aQIKu4qilrRzdPiI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.entgmum76f.wasm"
    },
    {
      "hash": "sha256-tiMn7eiYQDiFO0Dm0Tb2m73yQITP4Y0IlqUQLCOZhwQ=",
      "url": "_framework/System.Runtime.qoxjrkah1a.wasm"
    },
    {
      "hash": "sha256-jfuU/IfVJQN3new5xne32YLX2tHAZfoCmg7AjVHhw88=",
      "url": "_framework/System.Security.Cryptography.9d7dd6p8se.wasm"
    },
    {
      "hash": "sha256-1gLsgzBmjECacBqTABoQWBH/Z7+Mq86tWE2geNs7erU=",
      "url": "_framework/System.Text.Encodings.Web.qs638cchal.wasm"
    },
    {
      "hash": "sha256-p7c9GLx1Ow5jqEUsQ/JeOhEMFHQjm6rwDo8NhfHL7jw=",
      "url": "_framework/System.Text.Json.3h0t00thq2.wasm"
    },
    {
      "hash": "sha256-JzE0U8uus3eo/IOgcjjUy9BEWXuVr0Of/gUK6MismNY=",
      "url": "_framework/System.Text.RegularExpressions.lpo3blhv25.wasm"
    },
    {
      "hash": "sha256-s+4y+NQuK8FKwAdeZJU4TUmAmMqsKz8JGY1OQ7P0xAo=",
      "url": "_framework/System.Threading.Tasks.bufejdmstw.wasm"
    },
    {
      "hash": "sha256-7A2VUL5SS7XF9SMTD/1ZoA+DNXtehpDAPs15R9lyz3A=",
      "url": "_framework/System.sal18ehrzx.wasm"
    },
    {
      "hash": "sha256-YvRI3ig34ANY6CO4+hg6hSKsgDtmW8tt8frSS3thQYE=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-qJ9/OAF/VyTucBeLA5UhffqoSBGd0xW5fn7Dq6jZ+lo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-NdFSj8MM4tvhMRG2JPNXYDnzqZno/RjOpUq0dxHcPVw=",
      "url": "_framework/dotnet.native.boem75ye5i.wasm"
    },
    {
      "hash": "sha256-SvVveFrqwSE/8qjn/DA3aVnuMXhmK4Ln+euLxQu8azU=",
      "url": "_framework/dotnet.native.qc8g39g30v.js"
    },
    {
      "hash": "sha256-vM4cfmuAtxs/dLoxiTCzPyPCyNkwOJu14cp6lXv3Sak=",
      "url": "_framework/dotnet.runtime.opaiwunc3t.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-o6XUMiTL8fnMaM+7dyYuL3ifi7aDWRrSFICw/N/bQrY=",
      "url": "_framework/theonlytool.t0cihrpnv7.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
