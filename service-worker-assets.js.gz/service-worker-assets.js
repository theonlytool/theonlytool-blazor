self.assetsManifest = {
  "version": "zdjrzjYj",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-aidPadLZxrT3QQRS/xS1hNJ/bZX1RFYSPudkBnXh3Cw=",
      "url": "_framework/Services.Base64.6s618irnpn.wasm"
    },
    {
      "hash": "sha256-n05VHEahgmq1hIncdRqKf40CuWIxLhf3GAzr46pUcQs=",
      "url": "_framework/Services.Hashing.hsueu08f92.wasm"
    },
    {
      "hash": "sha256-DwBtwcDFq29PnWYJ9w1+qrbZYmuLMTGB9cTmzWcVw6o=",
      "url": "_framework/Services.Url.b9wn99hipn.wasm"
    },
    {
      "hash": "sha256-S0snUPWJvC9Q3c2FPB0SNNr9EDVzk4P9N8S8CXT5yeM=",
      "url": "_framework/System.3qa0pzb5pz.wasm"
    },
    {
      "hash": "sha256-gJfBm+KZVZjE6kIQy7/G9e6VVZod1rTFOel5C1zTTOg=",
      "url": "_framework/System.Collections.Concurrent.wg6vmocl93.wasm"
    },
    {
      "hash": "sha256-5lx/EUdbyMkIjjLGe2fhZgX0DAoyXN5u05Sj2Q2s/Sc=",
      "url": "_framework/System.Collections.Immutable.253sec62my.wasm"
    },
    {
      "hash": "sha256-C4lEJ96O9hzwPTfdkArXfIr5Cc1zSUbImEfBwtG2B7o=",
      "url": "_framework/System.Collections.tipnuif9we.wasm"
    },
    {
      "hash": "sha256-BMnFoz3QdB5YAAQWKuht0jbuZigOpderxHbEBxpnPx4=",
      "url": "_framework/System.ComponentModel.Annotations.or677lp5ij.wasm"
    },
    {
      "hash": "sha256-1RaZIG2/SUF8xOYI6MhEPXgoaB8WhMi97Eb63TCWNqo=",
      "url": "_framework/System.ComponentModel.Primitives.dy0c39ecy1.wasm"
    },
    {
      "hash": "sha256-xIx81gZhM13pTzuTV/gI5amKO4LK+YPTfXhD+/rqB4s=",
      "url": "_framework/System.ComponentModel.TypeConverter.w3v3fxut04.wasm"
    },
    {
      "hash": "sha256-weQDZqCdoX1B5N68l3ScBTN3kZfsSwFzXiThhwumfEc=",
      "url": "_framework/System.ComponentModel.x8c7bgkp9c.wasm"
    },
    {
      "hash": "sha256-vD0TNAAERqTb7EApDik1KIzhyBya7N9gZsOrLURiPVQ=",
      "url": "_framework/System.Console.48e96fzipt.wasm"
    },
    {
      "hash": "sha256-HT3kG2k3hV2Ox/0VmngMKsaMgZyw+crez7+0m/ajo6M=",
      "url": "_framework/System.Diagnostics.Debug.vd7abxr7t9.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-noaJsavSxBleXYS7Nbj5jEzNc5kSBiu5I4QuGHJXmS4=",
      "url": "_framework/System.IO.Pipelines.6q7i7yitvh.wasm"
    },
    {
      "hash": "sha256-EllGGoOrIca/3XwRf496GxfJ6KKwFw5KBfHLh2rfr0g=",
      "url": "_framework/System.Linq.Expressions.yr8iuvv0zf.wasm"
    },
    {
      "hash": "sha256-0XdijATvmOybyBsi2PdIgKkS++mhdzWKaCcZNMIOwKs=",
      "url": "_framework/System.Linq.b9yj0tgr5d.wasm"
    },
    {
      "hash": "sha256-ytBYrxcaI5VSxrgOe0EJa+5nlMHP5Vlpx1iE4yD+K18=",
      "url": "_framework/System.Memory.a82a7867b8.wasm"
    },
    {
      "hash": "sha256-3D4AbpQc7mCv6rKC+Xq5qBVF8vZ0RLuIwfotHujKbtQ=",
      "url": "_framework/System.Net.Http.syc62mmim7.wasm"
    },
    {
      "hash": "sha256-x0D9eaM2k9jJLRmhb++ExLeF7ICKbATxrS6vwNWNZRs=",
      "url": "_framework/System.Net.Primitives.trxhmthuu1.wasm"
    },
    {
      "hash": "sha256-2nFGoVkM37lmBcEMIYh8F1jsrZyV2GP9kIp8iq8G6rc=",
      "url": "_framework/System.ObjectModel.i6nupufb20.wasm"
    },
    {
      "hash": "sha256-0FhMCsKAS1x1kOAdZ3ZZxmWiGSTdxHsTkcrEZKAeYtQ=",
      "url": "_framework/System.Private.CoreLib.4fbsslqybl.wasm"
    },
    {
      "hash": "sha256-S7jduI4MBhvSCu/2qshtzPnqQ4FfnW2V9TrwAkr/YPg=",
      "url": "_framework/System.Private.Uri.t2xdvsz3ub.wasm"
    },
    {
      "hash": "sha256-XtcDDjJB5SLVy2Q/DduSMQJCZVcWpsGsBuhqDPK/X5g=",
      "url": "_framework/System.Resources.ResourceManager.2gqrmp9sk0.wasm"
    },
    {
      "hash": "sha256-CsrzEdx0GQQOCjiJOKV+T3KBMrV9yeeoSUU2SyZsep0=",
      "url": "_framework/System.Runtime.2i8k6jngz8.wasm"
    },
    {
      "hash": "sha256-lgRGyvp0m+b9c14Wks/rv25bEY0b0iizPiy3oNofETI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2e39mftte8.wasm"
    },
    {
      "hash": "sha256-/8j1TrixAZMkwU4IJkOI4UdEV2hL8jwAZF59wxNy4z0=",
      "url": "_framework/System.Security.Cryptography.3bb74g91eb.wasm"
    },
    {
      "hash": "sha256-Dtii1gDtbIOl8J73+IwD0DWRdOCX1N4lpncJl74DQP4=",
      "url": "_framework/System.Text.Encodings.Web.qe6aheca69.wasm"
    },
    {
      "hash": "sha256-PP45A1/dMRfOYR7HZAlQIAa+53zi7XwPg/RCqc09xAY=",
      "url": "_framework/System.Text.Json.87w30jhojc.wasm"
    },
    {
      "hash": "sha256-2nwlZfNOX+iNnL41BiVz59IC/drtMhUqJ2toSMyQgig=",
      "url": "_framework/System.Text.RegularExpressions.y9gvnymua3.wasm"
    },
    {
      "hash": "sha256-YEl02db4s7tZSs6/rTzCkaUX2Gx+hwou6qu9FvBNEyU=",
      "url": "_framework/System.Threading.Tasks.oquzbqflb1.wasm"
    },
    {
      "hash": "sha256-GrwHVP7e0ncG6sWywGOmWEqhAq5ofByZaLjtM44r530=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-urcFl2P3ib9HW1PNu/T/aDc1Rc+1hAGGSrxnVfFbiVQ=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-UERN7YR414/+hb1ncWnlCb4MfoY5G6n6GhBsmQh596c=",
      "url": "_framework/dotnet.native.gwaa25jr8v.wasm"
    },
    {
      "hash": "sha256-7XMc4zNw57kcSBKwrPlpEe7deQEmt1OLoq8hpDaJaXU=",
      "url": "_framework/dotnet.native.hzfg37297t.js"
    },
    {
      "hash": "sha256-yL6ar4vB8ArKxU/VnG/jJ1kTF7/5qO7XNmWdDU17km0=",
      "url": "_framework/dotnet.runtime.sv8x6wte7f.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-n3+NkRnRDLhGkbiJ95j7Z1K0i9ArJePveS1LnsvnG0w=",
      "url": "_framework/theonlytool.jvv5nuaczm.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
