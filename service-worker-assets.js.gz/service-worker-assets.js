self.assetsManifest = {
  "version": "wCI4xQTk",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-M6Bys8bE7r39UkTIS7z1OlYbDM9lIUZypnshTHd6ksQ=",
      "url": "_framework/Services.Base64.13qv6pw4cv.wasm"
    },
    {
      "hash": "sha256-DbJ2b8dcTBsrqW0DXfr6KEIR9Nev5JWhN8vhU+Y/BZc=",
      "url": "_framework/Services.Hashing.5e5joatzkr.wasm"
    },
    {
      "hash": "sha256-68ni5YyStOYT35yPFcFXGiQLiVPsxwqI3xQ8QbsOakA=",
      "url": "_framework/Services.Url.vn9878ipt9.wasm"
    },
    {
      "hash": "sha256-hNf54N1mG+nNOimwSxZCdMotRk/AjjS/nczs1vLTl/U=",
      "url": "_framework/System.Collections.Concurrent.gzosbw116o.wasm"
    },
    {
      "hash": "sha256-DN2YdU24CUBnx/ylqo41QzmZiOHU/7sz5/xo4zcyWvU=",
      "url": "_framework/System.Collections.Immutable.otmihac3e8.wasm"
    },
    {
      "hash": "sha256-MY0ug36mthNlifpWdx20BHPtdb0rhMTRBBxL+QSSJh0=",
      "url": "_framework/System.Collections.peeh6h49rv.wasm"
    },
    {
      "hash": "sha256-t9G6VTTQO0nWbSGlUUa8A3slMG/3e7ODeRnpiO1gIj4=",
      "url": "_framework/System.ComponentModel.Annotations.dvmuf0fkc1.wasm"
    },
    {
      "hash": "sha256-a1Sl7Y9rsJkHH8u+Qg+QR7sqg25+IJk++WF3OVjvGhY=",
      "url": "_framework/System.ComponentModel.Primitives.fjf3ruf3vp.wasm"
    },
    {
      "hash": "sha256-5sBiu4j7F3uY9FTDMs70kERNQ8K7BIATtKO25CSab4o=",
      "url": "_framework/System.ComponentModel.TypeConverter.a4g6gaj41j.wasm"
    },
    {
      "hash": "sha256-bbk7fMdbkK04JB27emI59H5Do37xuGvlxDf4cyZg6Uc=",
      "url": "_framework/System.ComponentModel.x32fl32bki.wasm"
    },
    {
      "hash": "sha256-HwO4xbZ3R2D+cKke99YE/ZA2FtoS2EqVWdeZHQQ98t0=",
      "url": "_framework/System.Console.pqis3bs089.wasm"
    },
    {
      "hash": "sha256-f2rzIYBGjrncYkqmTjmkXkKhTeixa/XVQwUS3lE2fg4=",
      "url": "_framework/System.Diagnostics.Debug.pm15mqktqz.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-q7mGEcpph+nlGWd4rmBSfmXRrRasjniRTy3iBAsX3So=",
      "url": "_framework/System.IO.Pipelines.xlksj35j40.wasm"
    },
    {
      "hash": "sha256-ECuEQceBr1ismAtpfm00csPVlCT9WqVP+dPXh0mLemU=",
      "url": "_framework/System.Linq.Expressions.kb9ny5r8av.wasm"
    },
    {
      "hash": "sha256-3lpGe/wR7bA4q9ucU0e6Dx526BTsJUGSd7PMJJL+lJw=",
      "url": "_framework/System.Linq.axvlyxof1s.wasm"
    },
    {
      "hash": "sha256-PmdNiG3/51v/xNAEPnwwsjIKeV6eTkYQhhrmoyKy8ms=",
      "url": "_framework/System.Memory.2k3zschlt1.wasm"
    },
    {
      "hash": "sha256-KNXWcO0nQtXdQcQi4z38zhB7R1AhWKSeqyOo1X069po=",
      "url": "_framework/System.Net.Http.wibuhl3lgm.wasm"
    },
    {
      "hash": "sha256-1y4I/y49VU9owasFk/RaSCfU/xzaE1eELg99KlQXorg=",
      "url": "_framework/System.Net.Primitives.bn126x5ac2.wasm"
    },
    {
      "hash": "sha256-ea0/3lDvzCN5V8Luld753rHOCFKMcLJ42s/YO0AHq5k=",
      "url": "_framework/System.ObjectModel.p064y5ut7q.wasm"
    },
    {
      "hash": "sha256-v2kADIu2sZO8wFPrhMes8TYfqwvP1m2Efz4JIVjIxZg=",
      "url": "_framework/System.Private.CoreLib.lzwprurtqn.wasm"
    },
    {
      "hash": "sha256-BwFUmLJBdtmKf++nn2GH+5NQc6/TNJdMaCKkELhNTUQ=",
      "url": "_framework/System.Private.Uri.1e0gpkhke4.wasm"
    },
    {
      "hash": "sha256-ajcXhi+N6QG1iZEDEaVT65ZTFIgNNEcZmVu1uUD+be4=",
      "url": "_framework/System.Resources.ResourceManager.mw4rr3dfcj.wasm"
    },
    {
      "hash": "sha256-hRX8cQR6TuNHthGNTOFA3J39ChDahJsvp0+OL6K5/lo=",
      "url": "_framework/System.Runtime.1x2ryjgttj.wasm"
    },
    {
      "hash": "sha256-hvMt1IDwhfTaPJfe1fJ80HJ5eAum8hxykr0I3aDRcoE=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.un6jcmgrxl.wasm"
    },
    {
      "hash": "sha256-+FJGu9onz+j6yyG4Px50dqTjnoRgbf06w1/9TQDdWoI=",
      "url": "_framework/System.Security.Cryptography.szc9njm470.wasm"
    },
    {
      "hash": "sha256-1qlvW+GPp2+gK7M0la3P+tFyvHLjnWdJxTTlRol4TkU=",
      "url": "_framework/System.Text.Encodings.Web.261hidhqyu.wasm"
    },
    {
      "hash": "sha256-Yyu5Q/LqR/vmtdHVoM0XJ6xo7peWIbLXpUxZlKU/p1M=",
      "url": "_framework/System.Text.Json.pllpv7mlxq.wasm"
    },
    {
      "hash": "sha256-ncHhng2C9aGwXi9Wu18bGOVFHL2nS2soFv4HlcTTfM8=",
      "url": "_framework/System.Text.RegularExpressions.7v04xc3z27.wasm"
    },
    {
      "hash": "sha256-jCo1JNZ0nBKQ9K/XDvbM4e2wtezfYGKYCBfUZ3WIUN8=",
      "url": "_framework/System.Threading.Tasks.05kyrcpsfu.wasm"
    },
    {
      "hash": "sha256-5QZAjy4n7513fYxCXSXTsAkUmRsLiZ8m621Ot4k7FB0=",
      "url": "_framework/System.dqfxtvioy0.wasm"
    },
    {
      "hash": "sha256-mlX7D6ts1gg0X375hd4PHuGSDPZHoN14z6cMl7bDSr4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-tgrZh46Y3JaZ+PyFFOnGPVYBjDDetP1k9QAKJlurdVI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HlUDSN0oXsH1WmjLNtyyvh9W0WQWWPGv3SJsHPJAwTE=",
      "url": "_framework/dotnet.native.etgrtk5jba.wasm"
    },
    {
      "hash": "sha256-CU8oL4L0VAwGe3hCyxZDy7keJq9dcsWED0JKqrvlUb4=",
      "url": "_framework/dotnet.native.l1ds2rhypd.js"
    },
    {
      "hash": "sha256-5oRcSUQSLbUYyq9jPgwB6domrDHYrvLX+53QxY+0y48=",
      "url": "_framework/dotnet.runtime.2hocyfcbj2.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-NyrAzM1v8zHI0nTI9TGch8sFIzBO6+eAUlftk/QeevU=",
      "url": "_framework/theonlytool.5ld4khov0d.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
