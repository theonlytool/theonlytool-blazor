self.assetsManifest = {
  "version": "/aMWPoBc",
  "assets": [
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-6rETCV3S3KdEjilEkpXZqjRmygknG7aqxUpotK6U++0=",
      "url": "_framework/MudBlazor.65z43161st.wasm"
    },
    {
      "hash": "sha256-eUUzhkGB4RrnP1GyuzXLlZNltM2hRpbAe+3h47Z0Obo=",
      "url": "_framework/Services.Base64.r3shy42oiy.wasm"
    },
    {
      "hash": "sha256-FXWYMmXPIuV6cibcj+o77IqzbDlS5NWC2JLLZtB8rGQ=",
      "url": "_framework/Services.Hashing.dmjzbr33ah.wasm"
    },
    {
      "hash": "sha256-DWSByuwj4g9Ou6V8Qz+pG9XrZVnUFGS190DYXEna0uw=",
      "url": "_framework/Services.Url.t4a3y3kmlf.wasm"
    },
    {
      "hash": "sha256-9Z3ENod6VeJLMMBIonzRZXrI8sRL/pzKKXZY8VLXkLY=",
      "url": "_framework/System.Collections.5g7lx9s9ux.wasm"
    },
    {
      "hash": "sha256-bYNDeX6Gq6CMvazBPcvH25FyKk+BCJqfq7JauxGQBIs=",
      "url": "_framework/System.Collections.Concurrent.rirpxpmwnm.wasm"
    },
    {
      "hash": "sha256-+e3k2Z+ya/lrbGyoZVGcpR8jjS0EXAJR0c9Lq0ukA0w=",
      "url": "_framework/System.Collections.Immutable.l1ku9tfo0f.wasm"
    },
    {
      "hash": "sha256-la/5DXgGdfgpUT20edMsYn2nb/vLh3sL3rmS/d09A1o=",
      "url": "_framework/System.ComponentModel.54g84uj3hp.wasm"
    },
    {
      "hash": "sha256-vgZy6RgZbZ6x6oMdYsQ3IhNuf+J0/hGyvWpiksTRSwY=",
      "url": "_framework/System.ComponentModel.Annotations.6no24vn1nf.wasm"
    },
    {
      "hash": "sha256-mXoSqJ6E97Zu+3F+4XhLhqNYqtDd742EQF2183pBNvY=",
      "url": "_framework/System.ComponentModel.Primitives.xqt86zs5lv.wasm"
    },
    {
      "hash": "sha256-ryQGpDRoHk4OgzcA0oxK9+CsduiqV6vbkpcIlXyuNF0=",
      "url": "_framework/System.ComponentModel.TypeConverter.bd9lqmhia2.wasm"
    },
    {
      "hash": "sha256-b4ckU6CRqzMhKHdHqdGqCMyF7lFaQ+7ZbS69kuVs6gs=",
      "url": "_framework/System.Console.7e7g235qc7.wasm"
    },
    {
      "hash": "sha256-4iaM67iI0F4i1V1QRL0o3MhkLsiPP9yiXzZWn7vMZy4=",
      "url": "_framework/System.Diagnostics.Debug.qmrkqpk7ow.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-HYkYhkZSipct0OgAjDNJUWvpDesLV9bQA9eJ6BiixR0=",
      "url": "_framework/System.IO.Pipelines.9d8z48tcc6.wasm"
    },
    {
      "hash": "sha256-ibd5FPJKBCfZD93gIDkLCFcBIhpN9GZSnRTZ69w7WqQ=",
      "url": "_framework/System.Linq.Expressions.n8gdhxqpe8.wasm"
    },
    {
      "hash": "sha256-mCIq9fyGt6NXnPgcNdQvGLV5svvYY3GBYVHb6QCdiv8=",
      "url": "_framework/System.Linq.w2ra3eyexi.wasm"
    },
    {
      "hash": "sha256-Jt+qlZIgYf9itdo0rnR+F1DsnFP87EzaLBjT83rRwEU=",
      "url": "_framework/System.Memory.2hsodbggic.wasm"
    },
    {
      "hash": "sha256-KVIY1PiATB7+IQnIs8iQk2DvtP7WYer3KQhMch42kp8=",
      "url": "_framework/System.Net.Http.7cel6v9dsm.wasm"
    },
    {
      "hash": "sha256-nXJWRdQ5Yo36TZlKp5xkUyoqTMB9iU3ST0h5I66TPLA=",
      "url": "_framework/System.Net.Primitives.z4n1udbibv.wasm"
    },
    {
      "hash": "sha256-tKeFAsuRJbG6CX4iCdXqOHHGbwqS0hQRW3nnetqL4Lo=",
      "url": "_framework/System.ObjectModel.gjxmlc63zy.wasm"
    },
    {
      "hash": "sha256-jtTzfx68NOQ538ZJ5Svt6bMIwn2SB1cEG8UGjZ4x26k=",
      "url": "_framework/System.Private.CoreLib.a9w5u5dblt.wasm"
    },
    {
      "hash": "sha256-koJSoUik6lLGxHGW2MRBmxjebwuGdLuFnfb/BPXU2Cw=",
      "url": "_framework/System.Private.Uri.my1eopi1pf.wasm"
    },
    {
      "hash": "sha256-rwqQSyZStHmiaXt9JoN2zyO+vDfJbWrVQXQPIvv1yCE=",
      "url": "_framework/System.Resources.ResourceManager.dxieizatg0.wasm"
    },
    {
      "hash": "sha256-4LYjaWKi4KrevpC9ZRt4hasWE5jfZIBmiENGBL4XWD0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.gsm3njtp1i.wasm"
    },
    {
      "hash": "sha256-8G8eKE+QvulSetmtqq33GiIzbLNYfFXPe+i6zdLJrZM=",
      "url": "_framework/System.Runtime.cp6cz8iaup.wasm"
    },
    {
      "hash": "sha256-UpV5N+9T5n/T+QIs7CaVw3BlPI9gNB3zYfeOrWCDPHQ=",
      "url": "_framework/System.Security.Cryptography.6yq57vh8ft.wasm"
    },
    {
      "hash": "sha256-+FzZMWMvkMT6/BxsRz7bKVB4FLqp1jArd9S4GBNq/Xw=",
      "url": "_framework/System.Text.Encodings.Web.c7w4brb90d.wasm"
    },
    {
      "hash": "sha256-R6UOv7jlpo/x6B2kYOqWu5DqkPR0Byl7b2gp2HGMVFc=",
      "url": "_framework/System.Text.Json.d7r8nefj8o.wasm"
    },
    {
      "hash": "sha256-hgs+jW/WJlAfPBie6x8IR670VeF6dFTWmWcmYD+vkIY=",
      "url": "_framework/System.Text.RegularExpressions.u61qzoqq5r.wasm"
    },
    {
      "hash": "sha256-zqrL+x53VE8HJIEtZ2oL8dXrXmeyy5GQojpmvvqW6UA=",
      "url": "_framework/System.Threading.Tasks.inwy9ac8f7.wasm"
    },
    {
      "hash": "sha256-V0+qqJsDHNUBCJjD4bkeDVr+f+Orz+wNldNNIxrsd+4=",
      "url": "_framework/System.v2bpr4wvug.wasm"
    },
    {
      "hash": "sha256-ni0jlCwz5mXdOYP3qI1GhsNDNXI3r06kOO9+ECn9dWM=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-ZAezHs19Cg11hskCNE7v5w59q4YN75Vxf6D1PlhwXyA=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-qvfJsMkiZ6OPXN1LC7yOFV9CbV5kMGULQQaOsficyFo=",
      "url": "_framework/dotnet.native.6sm8j8phll.wasm"
    },
    {
      "hash": "sha256-vmIOX4PNMW/lZiY9EBf+azWnO+yM3bxQOPRybnvEG2o=",
      "url": "_framework/dotnet.native.mf92lzu2d1.js"
    },
    {
      "hash": "sha256-zWiDiXCfePn0/nLx2lSoJaVxxUIAaYKqTG9DTZqR/Mw=",
      "url": "_framework/dotnet.runtime.7zon98f8ky.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-wx2DdeLE/uOqIW/JLoaRYVnOvdH8PePsKXgqN43L47Y=",
      "url": "_framework/theonlytool.dcoc8xza22.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
