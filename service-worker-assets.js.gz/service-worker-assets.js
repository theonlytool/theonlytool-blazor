self.assetsManifest = {
  "version": "E4W7gvf4",
  "assets": [
    {
      "hash": "sha256-TSgzDIY4qdWvjvfBaUSrnerVt2+FjH4cXGlPrxEz1C0=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-hylTyzoFC8Kp1f0FRqBY1LUV5GLhjEZGZbvrFnkZ1Tw=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Y4zzyUUVBtaN6kfbmMJgFFFHhE50hCkIp86Snf6KGRs=",
      "url": "_framework/Microsoft.AspNetCore.Components.1jbluefeqp.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-wDxLR6qY4LYrTg5jeBxNiFszgBwpRBTa+vd8DoBv5/E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k3obqto650.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-s3caNLGikAlzK7Zbgsjf4RETQ43EcfRsHU3U76XDiz8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.zo7f77cwpb.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-T8vdMKL2wM6XZ8W6A1SDa3vN5SWamebUijvh64HMJ0Q=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tx3rk9lhk3.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-5jZf2QiBkRnLptGZ9aRYLks5RgacU3aWxXt53Xj8BUY=",
      "url": "_framework/Microsoft.JSInterop.evnp8zttjq.wasm"
    },
    {
      "hash": "sha256-Pjf3czWeMVwiuVjoXL/ByH8J1O11RsUE1oSvT3l7wjQ=",
      "url": "_framework/MudBlazor.mu7ib1zu79.wasm"
    },
    {
      "hash": "sha256-Ab7E9tF8ZRcZLVwSkB14SQDBP2dcQXK5mwbT0/xqKyQ=",
      "url": "_framework/Services.Base64.5nwb44b6ou.wasm"
    },
    {
      "hash": "sha256-cnB5Gqm0nngbWMzUaI/1wjSarXattcTN2WPx8JoWfZA=",
      "url": "_framework/Services.Hashing.mblmzmgtkr.wasm"
    },
    {
      "hash": "sha256-otn1wQrA8NceT3VYG4oATIqQ6CLU1nGFEKSi3Jz3+cE=",
      "url": "_framework/Services.Url.y8y5tsfyak.wasm"
    },
    {
      "hash": "sha256-xMF0eauQ5DkSzUozHLFFMQnL6DSJO09nJLtgag+Dzbw=",
      "url": "_framework/System.8rv0tdtrxz.wasm"
    },
    {
      "hash": "sha256-H8IAFzGQb95gFrvJdlmQUkIOBaJpMgVwskOMqbp9Mh4=",
      "url": "_framework/System.Collections.Concurrent.fk0xlrwbpa.wasm"
    },
    {
      "hash": "sha256-TkDCGna6xanRr68E8sjV8+Hlg22LwCb9vIjfwCdcrwM=",
      "url": "_framework/System.Collections.Immutable.epm7h4xwhc.wasm"
    },
    {
      "hash": "sha256-6+I1UAS7wgr957nPVokCPmOz3EN61ZjG9d9ksucXMaU=",
      "url": "_framework/System.Collections.dyg93n03b3.wasm"
    },
    {
      "hash": "sha256-U5Jd9oGyDhXgPZfBdkkVYJrEWAFvWO5cLdl5eBQX2p8=",
      "url": "_framework/System.ComponentModel.Annotations.dcb1q9ajig.wasm"
    },
    {
      "hash": "sha256-MI155xcjTQ4mEtTTphXWxqSZ5eM086lDx6Hp8PyinQM=",
      "url": "_framework/System.ComponentModel.Primitives.wglichifzn.wasm"
    },
    {
      "hash": "sha256-oV5LEdpyq2MHFA5U/mGgkGM5XCKWg3EpPVInHIFGSkU=",
      "url": "_framework/System.ComponentModel.TypeConverter.hci7idqnn2.wasm"
    },
    {
      "hash": "sha256-P2bTPhn46nReTKHreFG6K47nCeDru/fCwA+UWdaZUK4=",
      "url": "_framework/System.ComponentModel.rp2ud0tstw.wasm"
    },
    {
      "hash": "sha256-T0McSbTvaabsa7znDGULI78YsMTGx0URhYK6Bid0quo=",
      "url": "_framework/System.Console.pyhjrkdhn0.wasm"
    },
    {
      "hash": "sha256-ikL7gTeA8/noZ4MH8yhvWmP6gKgQXWxkHZYTurLyz1o=",
      "url": "_framework/System.Diagnostics.Debug.ytovmeihc6.wasm"
    },
    {
      "hash": "sha256-CIqS8wFfljeeelEziuph4w+XxtekN8Zyazv2py/VP3w=",
      "url": "_framework/System.IO.Hashing.0axa7igz3n.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-BRw9zB32cbNQOF6R11X77C/cFQmRP40xg5ChvEu8kF4=",
      "url": "_framework/System.Linq.Expressions.x1skl37v1s.wasm"
    },
    {
      "hash": "sha256-WSd+Ufg3DeTarfRvU+itavGGz9hgJT5efM82w2FS4o8=",
      "url": "_framework/System.Linq.n0xeenz6n8.wasm"
    },
    {
      "hash": "sha256-z/QYwpls8A0orsj/ojT/lJJHkMbNLyxIb0u0RIJlvjc=",
      "url": "_framework/System.Memory.bp0h7ss33b.wasm"
    },
    {
      "hash": "sha256-+vqyxdE1+UA7vISnsC/CoYMA3LXzaLr7Eh0hQkgL3nw=",
      "url": "_framework/System.Net.Http.unyy781uvi.wasm"
    },
    {
      "hash": "sha256-QGfRxDDetU99gZZiBvpOeKywUoZ1QVAfJ0vfm6HWcb4=",
      "url": "_framework/System.Net.Primitives.om9mt4c0ro.wasm"
    },
    {
      "hash": "sha256-N3QsyzYPkkbmRuX5kJji/PIHqdPnn+6SYS7PjEii3T8=",
      "url": "_framework/System.ObjectModel.pkusu96sda.wasm"
    },
    {
      "hash": "sha256-NemvKhByHCt1nfdpccdsLQS75cO/NfAnlIm+eqP7W2g=",
      "url": "_framework/System.Private.CoreLib.tipo6rsu09.wasm"
    },
    {
      "hash": "sha256-YWnEp0kUSWe75GASLBqkhKiv4FtmoxkQHu37fYCPXXY=",
      "url": "_framework/System.Private.Uri.3r1vo5774a.wasm"
    },
    {
      "hash": "sha256-A9wNq0nDXvUnnDswgMqHD1Bz9L5ezaMlz7ewIdx4Fv8=",
      "url": "_framework/System.Resources.ResourceManager.ry248jky63.wasm"
    },
    {
      "hash": "sha256-fcbhHB7hDI448FbXH9oGRMD0YiK7sml91c0Cfomkn6c=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lu7n7av6ff.wasm"
    },
    {
      "hash": "sha256-eovXYHvB+r8x5NLlt4e37MCuvtT9KaTDs9CDluZZo2s=",
      "url": "_framework/System.Runtime.yq3mvg5zdq.wasm"
    },
    {
      "hash": "sha256-izG/2ckLPojgJ6S9GSPNnSGz42kasHfqPXid74rrMMU=",
      "url": "_framework/System.Security.Cryptography.pr1y5f1jvb.wasm"
    },
    {
      "hash": "sha256-SQ1+aS+lCxp43qhvbxWS01rhQfbvNeDSN0xyk2P9/Hc=",
      "url": "_framework/System.Text.Encodings.Web.hq94nfnuw2.wasm"
    },
    {
      "hash": "sha256-j7DlOifpUE4rzEIIs9BkuCowEYEnEOmvJ5KpzdtZRAc=",
      "url": "_framework/System.Text.Json.b94w73oc39.wasm"
    },
    {
      "hash": "sha256-AT7WYOcyvTgUKgJ5QmsIIqqmO6gNFDj0U7BIVZo/pdE=",
      "url": "_framework/System.Text.RegularExpressions.p2mtl1lsd1.wasm"
    },
    {
      "hash": "sha256-mnILwdCKAExR4FJDSl3Qk9ZhMjDfUYrwr1jSTeh/LBE=",
      "url": "_framework/System.Threading.Tasks.uj1zkr26fg.wasm"
    },
    {
      "hash": "sha256-NUQIXy7Fmv8hO676GXTvBmZabA97LVHmpiiGQW8wj8c=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-ZJi0aWKp4bh4MwPSRRjjKTi06SkP7KoMGOPGVlOr/MY=",
      "url": "_framework/dotnet.native.4cn5j8cbbi.wasm"
    },
    {
      "hash": "sha256-oBjTBMWipOBGg2SmgJr4yWw7x536rMCNCZgF62kqT0s=",
      "url": "_framework/dotnet.native.g0x6c0ef2o.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-xq90TEHGuis4k2jzazFd9oJaKH0QK+9LpKSEI9wE94Y=",
      "url": "_framework/theonlytool.60cg3v193o.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
